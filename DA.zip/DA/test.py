import random

# 定义范围的最小值和最大值
最小值 = 70.0 - 1.5
最大值 = 70.0 + 1.5

# 生成10组小数点后一位的随机数
随机数列表 = [round(random.uniform(最小值, 最大值), 1) for _ in range(10)]

print(随机数列表)
