from models.seg_net import *
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np

x = torch.rand(8, 256, 20, 20)
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
x = x.to(device)

model = DeepLabHeadV3Plus(256, 256, 4)
model = model.to(device)

y = model(x)
#one hot y
y = F.softmax(y, dim=1)
y = y[:, 1:, :, :]
print(y.shape)