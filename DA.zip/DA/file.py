import os
import glob
import shutil

import numpy as np
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
from PIL import Image
import cv2
from collections import OrderedDict
import random
from random import shuffle

import pydicom as dicomio
import nibabel as nib

import torch
import torch.utils.data
import torchvision
from torch.utils.data import Dataset
from torchsummary import summary
import torch.optim as optim
import torchvision.transforms as transforms
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from tqdm import tqdm
from torch_lr_finder import LRFinder
import albumentations as A
import torchio as tio
import SimpleITK as sitk


# dir_list = []
# path = 'd:/dataset/MMWHS'
# #
# # for i in range(1, 21):
# #     patient_label = i
# #     path = os.path.join(pth, 'mr_train', str(patient_label))
# #     dir_list.append(path)
# #
# # for dir in dir_list:
# #     p = dir + '/Masks'
# #     os.makedirs(p)
# #     p = dir + '/MR'
# #     os.makedirs(p)
# #
# #
# # for i in range(1001, 1021):
# #     patient_label = i
# #     pth = os.path.join(path, 'mr_train', 'mr_train_' + str(patient_label) + '_label.nii.gz')
# #     img = nib.load(pth)
# #     img_data = img.get_data()
# #     for s in range(img_data.shape[2]):
# #         slice_label = '{:03d}'.format(s+1)
# #         slice_img = img_data[:,:,s]
# #         slice_pth = os.path.join(path, 'mr_train', str(patient_label-1000), 'Masks', 'M_' + slice_label)
# #         np.save(slice_pth, slice_img)
#
#载入 Jpeg
# def load_jpeg(path):
#     img = Image.open(path)
#     img = np.array(img)
#     return img
# image = load_jpeg(r'D:\dataset\BraTS2Dpreprocessing\t1\mask\slice_000154.jpeg')
# mask = np.load(r"D:\dataset\BraTS2Dpreprocessing\t1\mask\mask_000154.npy")
# print(image.shape)
# print(mask.shape)
# #show image
# plt.imshow(image, cmap='gray')
# plt.show()
# #show mask
# plt.imshow(mask, cmap='gray')
# plt.show()
# #show mask on image
# plt.imshow(image, cmap='gray')
# plt.imshow(mask, alpha=0.5)
# plt.show()
#
#
#
# # ['bias_dim0', 'label_vol', 'dsize_dim1', 'dsize_dim2', 'lsize_dim1', 'mask_scale', 'bias_dim2', 'lsize_dim2', 'data_vol', 'mask_vol', 'bias_dim1', 'dsize_dim0', 'lsize_dim0'])
#
# from tfrecord.torch.dataset import TFRecordDataset
#
# tfrecord_path = 'D:/dataset/PnpAda_release_data/PnpAda_release_data/train&val/ct_train_tfs/ct_train_slice56.tfrecords'
# index_path = None
# description = {'data_vol': 'byte'}
# dataset = TFRecordDataset(tfrecord_path, index_path, description)
# loader = torch.utils.data.DataLoader(dataset, batch_size=1, shuffle=False, num_workers=0)
#
# data = next(iter(loader))['data_vol']
# data = data.squeeze(0)[0: 196608]
# data = torch.reshape(data, (256, 256, 3)).numpy().astype(np.float32)
#
# plt.imshow(data)
# plt.show()
#
# print(data)

# t1_name = '_t1.nii.gz'
# t2_name = '_t2.nii.gz'
# mask_name = '_seg.nii.gz'
#
# bratshgg_path = "/home1/jkwang/dataset/BraTS19/HGG"
# bratslgg_path = "/home1/jkwang/dataset/BraTS19/LGG"
#
# out_t1_image_path = "d:/dataset/BraTS2Dpreprocessing/t1Image"
# out_t2_image_path = "d:/dataset/BraTS2Dpreprocessing/t2Image"
# out_t1_mask_path = "d:/dataset/BraTS2Dpreprocessing/t1Mask"
# out_t2_mask_path = "d:/dataset/BraTS2Dpreprocessing/t2Mask"
# out_t1 = '/home1/jkwang/dataset/BraTS192D/t1_src'
# out_t2 = '/home1/jkwang/dataset/BraTS192D/t2_src'
# out_mask = '/home1/jkwang/dataset/BraTS192D/mask_src'
#
# if not os.path.exists(out_t1):
#     os.mkdir(out_t1)
# if not os.path.exists(out_t2):
#     os.mkdir(out_t2)
# if not os.path.exists(out_mask):
#     os.mkdir(out_mask)
#
#
# def file_name_path(file_dir, dir=True, file=False):
#     """
#     get root path,sub_dirs,all_sub_files
#     :param file_dir:
#     :return: dir or file
#     """
#     for root, dirs, files in os.walk(file_dir):
#         if len(dirs) and dir:
#             print("sub_dirs:", dirs)
#             return dirs
#         if len(files) and file:
#             print("files:", files)
#             return files
#
# pathhgg_list = file_name_path(bratshgg_path)
# pathlgg_list = file_name_path(bratslgg_path)
#
# def crop_ceter(img,croph,cropw):
#     #for n_slice in range(img.shape[0]):
#     height,width = img[0].shape
#     starth = height//2-(croph//2)
#     startw = width//2-(cropw//2)
#     return img[:,starth:starth+croph,startw:startw+cropw]
#
# for subsetindex in range(len(pathlgg_list)):
#     brats_subset_path = bratslgg_path + "/" + str(pathlgg_list[subsetindex]) + "/"
#     t1 = brats_subset_path + str(pathhgg_list[subsetindex]) + t1_name
#     t2 = brats_subset_path + str(pathhgg_list[subsetindex]) + t2_name
#     mask = brats_subset_path + str(pathlgg_list[subsetindex]) + mask_name
#     if os.path.exists(mask):
#         shutil.copy(mask, out_mask)
# #
# test = 'd:/dataset/BraTS2Dpreprocessing/t1/BraTS19_2013_0_1_t1.nii.gz'
# t1_src = sitk.ReadImage(test, sitk.sitkInt16)
# t1_arr = sitk.GetArrayFromImage(t1_src)
#
# t1_crop = crop_ceter(t1_arr, 160, 160)
# for n_slices in range(t1_crop.shape[0]):
#     t1Img = t1_crop[n_slices, :, :]
#     image = Image.fromarray(t1Img)
#     image.save(out_t1_image_path + "/" +  str(n_slices) + ".png")

# base_dir = '/home1/jkwang/dataset/S-Coro'
# def file_name_path(file_dir, dir=True, file=False):
#     """
#     get root path,sub_dirs,all_sub_files
#     :param file_dir:
#     :return: dir or file
#     """
#     for root, dirs, files in os.walk(file_dir):
#         if len(dirs) and dir:
#             print("sub_dirs:", dirs)
#             return dirs
#         if len(files) and file:
#             print("files:", files)
#             return files
#
# filename_list = file_name_path(base_dir, file=False)
#
# for item in filename_list:
#     print('\'item\'')
#     path = base_dir + '/' + item
#     print(path)
#     target_path = '/home1/jkwang/mri-segmentation-demo/nnformer/nnUNet_raw_data_base/nnFormer_raw_data/Task003_SCORO/'
#     for root, dirs, files in os.walk(path):
#         for file in files:
#             if os.path.splitext(file)[1] == '.gz':
#                 if 'seg' in file:
#                     shutil.copy(os.path.join(root, file), os.path.join(target_path, 'labelsTr'))
#                     #重命名
#                     os.rename(os.path.join(target_path, 'labelsTr', file), os.path.join(target_path, 'labelsTr', file.replace('seg', item + '_seg')))
#                 if 'image' in file:
#                     shutil.copy(os.path.join(root, file), os.path.join(target_path, 'imagesTr'))
#                     #重命名
#                     os.rename(os.path.join(target_path, 'imagesTr', file), os.path.join(target_path, 'imagesTr', file.replace('image', item)))


#列出所有文件
path = '/home1/jkwang/mri-segmentation-demo/nnformer/nnUNet_raw_data_base/nnFormer_raw_data/Task03_SCORO/labelsTr'
for root, dirs, files in os.walk(path):
    for file in files:
        if '_seg' in file:
            #重命名
            os.rename(os.path.join(path, file), os.path.join(path, file.replace('_seg', '')))