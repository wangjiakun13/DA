import torch
import torch.nn as nn
import torch.nn.functional as F

import matplotlib.pyplot as plt
import numpy as np

from models.auto_encoder import VQ_CVAE
from models import vct_brats

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
img_path = 'd:/dataset/BraTS2Dpreprocessing/img/BraTS19_2013_0_1/t1/t1_slice_141.png'

img = plt.imread(img_path)
img = np.expand_dims(img, axis=0)
img = np.expand_dims(img, axis=0)
img = torch.from_numpy(img).float().to(device)
model = VQ_CVAE(256, k=128, num_channels=1)
model.to(device)

model.load_state_dict(torch.load('d:/DA/VCT/model_200.pth', map_location=device))
z_e = model.encode(img)
z_q, _ = model.emb(z_e)

vct_enc = vct_brats.VCT_Encoder(z_index_dim=40)
vct_enc.to(device)
checkpoint = torch.load('d:/DA/VCT/model_5000.pth', map_location=device)

vct_enc.load_state_dict(checkpoint['encoder_model_state_dict'])
vct_dec = vct_brats.VCT_Decoder(index_num=128, z_index_dim=1600, ce_loss=True)
vct_dec.to(device)
vct_dec.load_state_dict(checkpoint['decoder_model_state_dict'])

latent = vct_enc(z_q)
recon = vct_dec(latent)