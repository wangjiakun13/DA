import os
import numpy as np
import logging
import gc
from skimage import transform
import glob
import zipfile, re
import utils_file as utils
from PIL import Image


def natural_sort(l):
    convert = lambda text: int(text) if text.isdigit() else text.lower()
    alphanum_key = lambda key: [convert(c) for c in re.split('([0-9]+)', key)]
    return sorted(l, key=alphanum_key)


def get_custom_file_paths(folder, name):
    image_file_paths = []
    for root, _, filenames in os.walk(folder):
        filenames = sorted(filenames)
        for filename in filenames:
            if filename.endswith(name):
                file_path = os.path.join(root, filename)
                image_file_paths.append(file_path)
    return image_file_paths

def crop_ceter(img,croph,cropw):
    #for n_slice in range(img.shape[0]):
    height,width = img[0].shape
    starth = height//2-(croph//2)
    startw = width//2-(cropw//2)
    return img[starth:starth+croph, :,  startw:startw+cropw]

def file_name_path(file_dir, dir=False, file=True):
    """
    get root path,sub_dirs,all_sub_files
    :param file_dir:
    :return: dir or file
    """
    for root, dirs, files in os.walk(file_dir):
        if len(dirs) and dir:
            print("sub_dirs:", dirs)
            return dirs
        if len(files) and file:
            print("files:", files)
            return files

def process_data(input_foler, processed_folder, size, target_resolution):
    # t1_image_paths = natural_sort(get_custom_file_paths(input_foler, "t1.nii.gz"))
    # t1_mask_paths = natural_sort(get_custom_file_paths(input_foler, "seg.nii.gz"))
    # t1_path = "/home1/jkwang/dataset/BraTS192D/t1_src"
    # mask_path = "/home1/jkwang/dataset/BraTS192D/mask_src"
    # t2_path = "/home1/jkwang/dataset/BraTS192D/t2_src"
    # t1_list = file_name_path(t1_path, file=True)
    # t2_list = file_name_path(t2_path, file=True)
    # mask_list = file_name_path(mask_path, file=True)

    hgg_path = '/home1/jkwang/dataset/BraTS19/HGG'
    lgg_path = '/home1/jkwang/dataset/BraTS19/LGG'

    hgg_list = file_name_path(hgg_path, dir=True, file=False)
    lgg_list = file_name_path(lgg_path, dir=True, file=False)
    for filename in hgg_list:
        t1_path = hgg_path + '/' + filename + '/' + filename + '_t1.nii.gz'
        t2_path = hgg_path + '/' + filename + '/' + filename + '_t2.nii.gz'
        mask_path = hgg_path + '/' + filename + '/' + filename + '_seg.nii.gz'
        image, _, image_hdr = utils.load_nii(t1_path)
        # print(image.shape)
        image = utils.crop_or_pad_volume_to_size_along_x(image, 256)
        image = utils.crop_or_pad_volume_to_size_along_y(image, 256)
        image = utils.crop_or_pad_volume_to_size_along_z(image, 256)

        # ==================
        # normalize the image
        # ==================
        image_normalized = utils.normalise_image(image, norm_type='div_by_max')
        # ======================================================
        # rescale, crop / pad to make all images of the required size and resolution
        # ======================================================
        scale_vector = [image_hdr.get_zooms()[0] / target_resolution[0],
                        image_hdr.get_zooms()[1] / target_resolution[1],
                        image_hdr.get_zooms()[2] / target_resolution[2]]

        image_rescaled = image_normalized
        volume_dir = os.path.join(processed_folder, 'image')
        os.makedirs(volume_dir, exist_ok=True)
        image_rescaled = crop_ceter(image_rescaled, 160, 160)

        mask, _, mask_hdr = utils.load_nii(mask_path)
        # print(image.shape)
        mask = utils.crop_or_pad_volume_to_size_along_x(mask, 256)
        mask = utils.crop_or_pad_volume_to_size_along_y(mask, 256)
        mask = utils.crop_or_pad_volume_to_size_along_z(mask, 256)

        # ==================
        # normalize the image
        # ==================
        # image_normalized = utils.normalise_image(mask, norm_type='div_by_max')
        # ======================================================
        # rescale, crop / pad to make all images of the required size and resolution
        # ======================================================

        volume_dir = os.path.join(processed_folder, 'mask')
        os.makedirs(volume_dir, exist_ok=True)
        mask = crop_ceter(mask, 160, 160)
        mask = mask.astype(np.uint8)
        dir_path = os.path.join('/home1/jkwang/dataset/BraTS192D/img', filename)
        if os.path.exists(dir_path):
            os.makedirs(dir_path, exist_ok=True)
        dir_t1_path = os.path.join(dir_path, 't1')
        dir_t2_path = os.path.join(dir_path, 't2')
        dir_mask_path = os.path.join(dir_path, 'mask')
        if not os.path.exists(dir_t1_path):
            os.makedirs(dir_t1_path, exist_ok=True)
        if not os.path.exists(dir_t2_path):
            os.makedirs(dir_t2_path, exist_ok=True)
        if not os.path.exists(dir_mask_path):
            os.makedirs(dir_mask_path, exist_ok=True)
        for i in range(size[1]):
            mask_slice = mask[:, i, :]
            if np.max(mask_slice) != 0:
                slice_path = os.path.join(dir_t1_path, "t1_slice_{:03d}.png".format(i))
                slice = image_rescaled[:, i, :] * 255
                image = Image.fromarray(slice.astype(np.uint8))
                image.save(slice_path)
                m_path = os.path.join(dir_path, 'mask', "mask_{:03d}.png".format(i))
                mask_slice = mask[:, i, :]
                mask_img = Image.fromarray(mask_slice.astype(np.uint8))
                mask_img.save(m_path)





def load_and_process_data(input_folder,
                          processed_folder
                          , size,
                          target_resolution):
    utils.makefolder(processed_folder)

    logging.info("Processing Now!")
    process_data(input_folder, processed_folder, size, target_resolution)
    logging.info("Processing finished!")


input_folder = "D:/dataset/BraTS2Dpreprocessing/test"
input_mask_folder = "D:/dataset/BraTS2Dpreprocessing/test_m"
process_foler = "D:/dataset/BraTS2Dpreprocessing/t1"
load_and_process_data(input_folder, process_foler,size =(256, 256, 256), target_resolution=(0.7, 0.7, 0.7))
