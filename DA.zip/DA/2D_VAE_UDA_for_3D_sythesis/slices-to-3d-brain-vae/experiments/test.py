from main_experiment_256 import *
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('TKAgg')
plt.rcParams['figure.figsize'] = (60, 20)
import torch

import PIL.Image as Image
#%%
import sklearn
import sklearn.decomposition
#%%
batch_size = 256
#%%
os.getcwd()
#%%
encoder = Encoder(1, gf_dim=4)
decoder = Decoder(1, gf_dim=4)

encoder = encoder.to(device())
decoder = decoder.to(device())

load_path = 'trained_models/vol_256_lr_0.001_kl_0.2__bsize_128/model_00000055.pth.tar'

print('Cuda is {}available'.format('' if torch.cuda.is_available() else 'not '))

checkpoint = torch.load(load_path, map_location=device())
start_epoch = checkpoint['epoch']
encoder.load_state_dict(checkpoint['encoder'])
decoder.load_state_dict(checkpoint['decoder'])
step = checkpoint['step']
print("=> loaded")


device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
print(encoder)
print(decoder)
encoder = encoder.to(device)
decoder = decoder.to(device)

image = Image.open('E:\\slices-to-3d-brain-vae\\experiments\\MICCAI-release-version\\slice_000103.jpeg')
image = np.array(image)
image = image.astype(np.float32)
image = torchvision.transforms.functional.to_tensor(image)

image = image.to(device)
image = image.unsqueeze(0)

latent, _, _ = encoder(image)
recon = decoder(latent)

recon = recon.squeeze(0)
recon = recon.cpu()
recon = recon.detach().numpy()
recon = np.transpose(recon, (1, 2, 0))
#show recon
plt.imshow(recon, cmap='gray')
plt.show()