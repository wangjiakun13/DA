from . import resnet
from . import mobilenetv2
from . import hrnetv2
from . import xception
