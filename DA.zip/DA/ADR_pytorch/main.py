from datetime import datetime
import json
import numpy as np
import random
import os
import time
import glob

import data_loader, losses
from model import *
from stats_func import *


from tqdm import tqdm

import torch
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

random_seed = 1234



class ADR:

    def __init__(self, config):
        current_time = datetime.now().strftime("%Y%m%d-%H%M%S")
        self._source_train_pth = config['source_train_pth']
        self._target_train_pth = config['target_train_pth']
        self._source_val_pth = config['source_val_pth']
        self._target_val_pth = config['target_val_pth']
        self._output_root_dir = config['output_root_dir']
        if not os.path.isdir(self._output_root_dir):
            os.makedirs(self._output_root_dir)
        self._output_dir = os.path.join(self._output_root_dir, current_time)
        self._output_select_dir = os.path.join('./output_select', current_time)
        self._skip = bool(config['skip'])
        self._num_cls = int(config['num_cls'])
        self._base_lr = float(config['base_lr'])
        self._max_step = int(config['max_step'])
        self._keep_rate_value = float(config['keep_rate_value'])
        self._is_training_value = bool(config['is_training_value'])
        self._batch_size = int(config['batch_size'])
        self._to_restore = bool(config['to_restore'])
        self._checkpoint_dir = config['checkpoint_dir']
        self._weight_decay = float(config['weight_decay'])

    def train(self):
        source_path_list = {}
        source_path_list['CT'] = {}
        source_path_list['Masks'] = {}
        source_image_cnt = {}
        source_mask_cnt = {}

        for i in range(1, 21):
            patient_label = i
            source_path_list['CT']['Patient' + str(patient_label)] = sorted(
                glob.glob('/home1/jkwang/dataset/MMWHS/ct_train' + '/' + str(patient_label) + '/CT/*.npy'))
            source_image_cnt['Patient' + str(patient_label)] = len(
                source_path_list['CT']['Patient' + str(patient_label)])
            source_path_list['Masks']['Patient' + str(patient_label)] = sorted(
                glob.glob('/home1/jkwang/dataset/MMWHS/ct_train' + '/' + str(patient_label) + '/Masks/*.npy'))
            source_mask_cnt['Patient' + str(patient_label)] = len(
                source_path_list['Masks']['Patient' + str(patient_label)])

        keys_to_delete = [k for k in source_image_cnt if
                          source_image_cnt[k] != source_mask_cnt[k] or source_image_cnt[k] == 0
                          or source_mask_cnt[k] == 0]

        for k in keys_to_delete:
            del source_image_cnt[k], source_mask_cnt[k], source_path_list['CT'][k], \
                source_path_list['Masks'][k]

        source_part = data_loader.partitioning([*source_image_cnt.keys()], split_ratio=[0.8, 0.1, 0.1])
        source_partition_train = {}
        source_partition_train['CT'] = []
        source_partition_train['Masks'] = []
        for p in source_part['train']:
            source_partition_train['CT'].extend(source_path_list['CT'][p])
            source_partition_train['Masks'].extend(source_path_list['Masks'][p])
        source_partition_valid = {}
        source_partition_valid['CT'] = []
        source_partition_valid['Masks'] = []
        for p in source_part['valid']:
            source_partition_valid['CT'].extend(source_path_list['CT'][p])
            source_partition_valid['Masks'].extend(source_path_list['Masks'][p])
        source_partition_test = {}
        for p in source_part['test']:
            source_partition_test[p] = {}
            source_partition_test[p]['CT'] = []
            source_partition_test[p]['Masks'] = []
            source_partition_test[p]['CT'].extend(source_path_list['CT'][p])
            source_partition_test[p]['Masks'].extend(source_path_list['Masks'][p])


        source_dataset_train = data_loader.MM_2D_dataset_source(source_partition_train, augment=False)
        source_dataset_valid = data_loader.MM_2D_dataset_source(source_partition_test, augment=False)
        source_dataset_test = {}

        source_loaders = {}
        for p in source_partition_test:
            source_dataset_test[p] = data_loader.MM_2D_dataset_source(source_partition_test[p], augment=False)
        source_loaders['train'] = torch.utils.data.DataLoader(source_dataset_train,
                                                       batch_size=self._batch_size,
                                                       shuffle=True,
                                                       num_workers=4)
        source_loaders['valid'] = torch.utils.data.DataLoader(source_dataset_valid,
                                                       batch_size=self._batch_size,
                                                       shuffle=False,
                                                       num_workers=4)

        target_path_list = {}
        target_path_list['MR'] = {}
        target_path_list['Masks'] = {}
        target_image_cnt = {}
        target_mask_cnt = {}

        for i in range(1, 21):
            patient_label = i
            target_path_list['MR']['Patient' + str(patient_label)] = sorted(
                glob.glob('/home1/jkwang/dataset/MMWHS/mr_train' + '/' + str(patient_label) + '/MR/*.npy'))
            target_image_cnt['Patient' + str(patient_label)] = len(
                target_path_list['MR']['Patient' + str(patient_label)])
            target_path_list['Masks']['Patient' + str(patient_label)] = sorted(
                glob.glob('/home1/jkwang/dataset/MMWHS/mr_train' + '/' + str(patient_label) + '/Masks/*.npy'))
            target_mask_cnt['Patient' + str(patient_label)] = len(
               target_path_list['Masks']['Patient' + str(patient_label)])

        keys_to_delete = [k for k in target_image_cnt if
                          target_image_cnt[k] != target_mask_cnt[k] or target_image_cnt[k] == 0
                          or target_mask_cnt[k] == 0]

        for k in keys_to_delete:
            del target_image_cnt[k], target_mask_cnt[k], target_path_list['MR'][k], \
                target_path_list['Masks'][k]

        target_part = data_loader.partitioning([*target_image_cnt.keys()], split_ratio=[0.8, 0.1, 0.1])
        target_partition_train = {}
        target_partition_train['MR'] = []
        target_partition_train['Masks'] = []
        for p in target_part['train']:
            target_partition_train['MR'].extend(target_path_list['MR'][p])
            target_partition_train['Masks'].extend(target_path_list['Masks'][p])
        target_partition_valid = {}
        target_partition_valid['MR'] = []
        target_partition_valid['Masks'] = []
        for p in target_part['valid']:
            target_partition_valid['MR'].extend(target_path_list['MR'][p])
            target_partition_valid['Masks'].extend(target_path_list['Masks'][p])
        target_partition_test = {}
        for p in target_part['test']:
            target_partition_test[p] = {}
            target_partition_test[p]['MR'] = []
            target_partition_test[p]['Masks'] = []
            target_partition_test[p]['MR'].extend(target_path_list['MR'][p])
            target_partition_test[p]['Masks'].extend(target_path_list['Masks'][p])

        target_dataset_train = data_loader.MM_2D_dataset_target(target_partition_train, augment=False)
        target_dataset_valid = data_loader.MM_2D_dataset_target(target_partition_test, augment=False)
        target_dataset_test = {}

        target_loaders = {}
        for p in target_partition_test:
            target_dataset_test[p] = data_loader.MM_2D_dataset_target(target_partition_test[p], augment=False)
        target_loaders['train'] = torch.utils.data.DataLoader(target_dataset_train,
                                                              batch_size=self._batch_size,
                                                              shuffle=True,
                                                              num_workers=0)
        target_loaders['valid'] = torch.utils.data.DataLoader(target_dataset_valid,
                                                              batch_size=self._batch_size,
                                                              shuffle=False,
                                                              num_workers=0)

        loaders = {}
        loaders['source'] = source_loaders
        loaders['target'] = target_loaders
        # optimizer_z = torch.optim.Adam(self._model.parameters(), lr=self._lr)
        # optimizer_seg = torch.optim.Adam(self._model.parameters(), lr=self._lr)
        # optimizer_d = torch.optim.Adam(self._model.parameters(), lr=self._lr)
        # optimizer_cls = torch.optim.Adam(self._model.parameters(), lr=self._lr)
        # optimizer_gd = torch.optim.Adam(self._model.parameters(), lr=self._lr)
        #
        # scheduler = torch.optim.lr_scheduler.ExponentialLR(optimizer_z, gamma=0.9)

        # out_path = os.path.join(self._out_path, 'results')

        model = Outputs()
        model.cuda()
        # if not os.path.exists(out_path):
        #     os.makedirs(out_path)
        for epoch in tqdm(range(1, 100), total=100+ 1):
            print('Epoch {}/{}'.format(epoch, 100))
            model.train()
            print('Training')
            for batch_idx, (source_data, target_data) in enumerate(zip(source_loaders['train'], target_loaders['train'])):
                source_data = source_data.cuda()
                target_data = target_data.cuda()

            for batch_idx, (s_data, s_gt) in enumerate(source_loaders['train']):
                data, target = data.cuda(), target.cuda()
                optimizer_z.zero_grad()
                outputs = model(data)
                spf_a = outputs['spf_a']
                spf_b = outputs['spf_b']
                inv_a = outputs['inv_a']
                inv_b = outputs['inv_b']
                logist_spf_a = outputs['logist_spf_a']
                logist_spf_b = outputs['logist_spf_b']
                logist_inv_a = outputs['logist_inv_a']
                logist_inv_b = outputs['logist_inv_b']

                dis_pred_real_a = outputs['dis_pred_real_a']
                dis_pred_real_b = outputs['dis_pred_real_b']

                pred_real_a = outputs['pred_real_a']
                pred_real_b = outputs['pred_real_b']

                spf_a_aux = outputs['spf_a_aux']
                spf_b_aux = outputs['spf_b_aux']
                inv_a_aux = outputs['inv_a_aux']
                inv_b_aux = outputs['inv_b_aux']
                logist_spf_a_aux = outputs['logist_spf_a_aux']
                logist_spf_b_aux = outputs['logist_spf_b_aux']
                logist_inv_a_aux = outputs['logist_inv_a_aux']
                logist_inv_b_aux = outputs['logist_inv_b_aux']

                dis_pred_real_a_aux = outputs['dis_pred_real_a_aux']
                dis_pred_real_b_aux = outputs['dis_pred_real_b_aux']

                pred_real_a_aux = outputs['pred_real_a_aux']
                pred_real_b_aux = outputs['pred_real_b_aux']

                fake_images_b = outputs['fake_images_b']
                dis_real_b = outputs['dis_real_b']
                dis_fake_b = outputs['dis_fake_b']

                cls_spf_a = outputs['cls_spf_a']
                cls_spf_b = outputs['cls_spf_b']

                predicter_real_a = nn.Softmax(dim=1)(pred_real_a)
                compact_pred_real_a = torch.argmax(predicter_real_a, dim=1)
                # compact_y_pred_real_a = torch.argmax(target, dim=1)

                predicter_real_b = nn.Softmax(dim=1)(pred_real_b)
                compact_pred_real_b = torch.argmax(predicter_real_b, dim=1)
                # compact_y_pred_real_b = torch.argmax(target, dim=1)

                dice_a_arr = dice_eval(compact_pred_real_a, target, self._num_cls)
                dice_a_mean = np.mean(dice_a_arr)
                dice_a_mean_sum = torch.sum(dice_a_mean)

                dice_b_arr = dice_eval(compact_pred_real_b, target, self._num_cls)
                dice_b_mean = np.mean(dice_b_arr)
                dice_b_mean_sum = torch.sum(dice_b_mean)

                a_val_dice = dice_a_mean_sum.item()
                b_val_dice = dice_b_mean_sum.item()

                hsic_loss_a = losses.HSIC(logist_spf_a, logist_inv_a)
                hsic_loss_b = losses.HSIC(logist_spf_b, logist_inv_b)
                hsic_loss = 0.5 * (hsic_loss_a + hsic_loss_b)

                #sigmoid cross entropy loss

                spf_domain_loss_a = nn.BCELoss



def main(config_filename):
    os.environ['PYTHONHASHSEED'] = str(random_seed)
    np.random.seed(random_seed)
    random.seed(random_seed)
    torch.manual_seed(random_seed)
    torch.cuda.manual_seed(random_seed)

    with open(config_filename) as f:
        config = json.load(f)

    model = ADR(config)
    model.train()


if __name__ == '__main__':
    main(config_filename='./config.json')