import torch
import torch.utils.data
from torch.utils.data import Dataset
import albumentations as A
import torchio as tio
import random
from random import shuffle
from PIL import Image
import torch.nn.functional as F
import numpy as np
import os

from torchvision import transforms


def partitioning(patients_list, split_ratio):
    part = {'train': [], 'valid': [], 'test': []}
    random.shuffle(patients_list)
    l = len(patients_list)
    split_pt = [int(split_ratio[0] * l), int((split_ratio[0] + split_ratio[1]) * l)]
    part['train'] = patients_list[:split_pt[0]]
    part['valid'] = patients_list[split_pt[0]:split_pt[1]]
    part['test'] = patients_list[split_pt[1]:]
    print('train: ', len(part['train']), ' ', 'valid: ', len(part['valid']), ' ', 'test: ', len(part['test']))
    return part

class MM_2D_dataset_source(Dataset):
    def __init__(self, partition, augment=False):
        self.partition = partition
        self.augment = augment


    def __len__(self):
        return (len(self.partition['CT']))

    def __getitem__(self, idx):
        image = np.load(self.partition['CT'][idx]).astype(np.float32)
        mask = np.load(self.partition['Masks'][idx]).astype(np.float32)
        t1 = transforms.ToTensor()

        if self.augment:
            image = self.augment(image)
            mask = self.augment(mask)
        else:
            image = t1(image)
            mask = torch.as_tensor(mask)

        mask = torch.unsqueeze(mask, 0)
        #resize
        image = transforms.Resize((224, 224))(image)
        mask = transforms.Resize((224, 224))(mask)
        image = image.type(torch.FloatTensor)
        mask = mask.type(torch.FloatTensor)

        return image, mask

class Pancrease_2D_dataset(Dataset):
    def __init__(self, partition, augment=False):
        self.partition = partition
        self.augment = augment

        self.aug = A.Compose([
            A.OneOf([
                A.Rotate(limit=15),
                A.VerticalFlip()], p=0.7),
            A.PadIfNeeded(min_height=256, min_width=256, p=1),
            A.GridDistortion(p=0.5)])

    def __len__(self):
        return (len(self.partition['CT']))

    def __getitem__(self, idx):
        # Generate one batch of data
        image = Image.open(self.partition['CT'][idx])
        mask = Image.open(self.partition['Masks'][idx])
        image = np.array(image)
        mask = np.array(mask)
        t1 = transforms.ToTensor()
        if self.augment:
            augmented = self.aug(image=image, mask=mask)
            image = t1(augmented['image'])
            """
            https://pytorch.org/docs/stable/torchvision/transforms.html
            Because the input image is scaled to [0.0, 1.0], totensor 
            transformation should not be used when transforming target 
            image masks.
            https://github.com/pytorch/vision/blob/master/references/segmentation/\
            transforms.py
            """
            mask = torch.as_tensor(augmented['mask'])
        else:
            image = t1(image)
            mask = torch.as_tensor(mask)

        mask = torch.unsqueeze(mask, 0)
        image = image.type(torch.FloatTensor)
        image = transforms.Resize((224, 224))(image)
        # note that mask is integer
        mask = mask.type(torch.IntTensor)

        # Return image and mask pair tensors
        return image, mask

class MM_2D_dataset_target(Dataset):
    def __init__(self, partition, augment=False):
        self.partition = partition
        self.augment = augment


    def __len__(self):
        return (len(self.partition['MR']))

    def __getitem__(self, idx):
        image = np.load(self.partition['MR'][idx]).astype(np.float32)
        mask = np.load(self.partition['Masks'][idx]).astype(np.float32)
        t1 = transforms.ToTensor()

        if self.augment:
            image = self.augment(image)
            mask = self.augment(mask)
        else:
            image = t1(image)
            mask = torch.as_tensor(mask)

        mask = torch.unsqueeze(mask, 0)
        image = transforms.Resize((256, 256))(image)
        mask = transforms.Resize((256, 256))(mask)
        image = image.type(torch.FloatTensor)
        mask = mask.type(torch.FloatTensor)



        return image