import os
import math
import numpy as np
import torch.nn as nn
import torch.functional as F

os.environ['CUDA_VISIBLE_DEVICES'] = '1'

import torch
from torch import optim
import logger
import argparse
import datetime
import gin
import itertools
import dataset
from torchvision import datasets, transforms
import evaluate

from imageio import imwrite
from torchvision.utils import make_grid
# from
from models.auto_encoder import *
import math
import random
import data.ground_truth.shapes3d as dshapes3d
import data.ground_truth.mpi3d as dmpi3d
import data.ground_truth.dsprites as ddsprit
import data.ground_truth.cars3d as dcars3d

from tensorboardX import SummaryWriter

from models.seg_net import *
from utils.loss import *
from utils.metrics import *

models = {
    'custom': {'vqvae': VQ_CVAE,
               'vqvae2': VQ_CVAE2},
    'imagenet': {'vqvae': VQ_CVAE,
                 'vqvae2': VQ_CVAE2},
    'cifar10': {'vae': CVAE,
                'vqvae': VQ_CVAE,
                'vqvae2': VQ_CVAE2},
    'mnist': {'vae': VAE,
              'vqvae': VQ_CVAE},
    'shapes3d': {
        'vqvae': VQ_CVAE
    },
    'dsprites': {'vae': VAE,
                 'vqvae': VQ_CVAE},
    'mpi_toy': {
        'vqvae': VQ_CVAE
    },
    'mpi_mid': {
        'vqvae': VQ_CVAE
    },
    'mpi_real': {
        'vqvae': VQ_CVAE
    },
    'clevr': {
        'vqvae': VQ_CVAE
    },
    'celebanpz': {
        'vqvae': VQ_CVAE
    },
    'celeba': {
        'vqvae': VQ_CVAE
    },
    'cars3d': {
        'vqvae': VQ_CVAE
    }
}
datasets_classes = {
    'custom': datasets.ImageFolder,
    'imagenet': datasets.ImageFolder,
    'cifar10': datasets.CIFAR10,
    'mnist': datasets.MNIST,
    # 'mnist' : dataset.custum_dataset,
    'shapes3d': dataset.custum_dataset,
    'dsprites': dataset.custum_dataset,
    'mpi_toy': dataset.custum_dataset,
    'mpi_mid': dataset.custum_dataset,
    'mpi_real': dataset.custum_dataset,
    'clevr': dataset.custum_dataset,
    'celebanpz': dataset.custum_dataset,
    'celeba': dataset.custum_dataset,
    'cars3d': dataset.custum_dataset,

}
dataset_train_args = {
    'custom': {},
    'imagenet': {},
    'cifar10': {'train': True, 'download': True},
    'mnist': {'train': True, 'download': True},
    # 'mnist' : {'name':'mnist'},
    'shapes3d': {},
    'dsprites': {'name': 'dsprites'},
    'mpi_toy': {'name': 'mpi_toy'},
    'mpi_mid': {'name': 'mpi_mid'},
    'mpi_real': {'name': 'mpi_real'},
    'clevr': {'name': 'clevr'},
    'celebanpz': {'name': "celebanpz"},
    'celeba': {'name': "celeba"},
    'cars3d': {'name': 'cars3d'}

}
dataset_test_args = {
    'custom': {},
    'imagenet': {},
    'cifar10': {'train': False, 'download': True},
    # 'mnist': {'train': False, 'download': True},
    'mnist': {'name': 'mnist'},
    'shapes3d': {},
    'dsprites': {'name': 'dsprites'},
    'mpi_toy': {'name': 'mpi_toy'},
    'mpi_mid': {'name': 'mpi_mid'},
    'mpi_real': {'name': 'mpi_real'},
    'clevr': {'name': 'clevr'},
    'celebanpz': {'name': "celebanpz"},
    'celeba': {'name': "celeba"},
    'cars3d': {'name': 'cars3d'}
}
dataset_n_channels = {
    'custom': 3,
    'imagenet': 3,
    'cifar10': 3,
    'shapes3d': 3,
    'dsprites': 1,
    'mnist': 1,
    'mpi_toy': 3,
    'mpi_mid': 3,
    'mpi_real': 3,
    'clevr': 3,
    'celebanpz': 3,
    'celeba': 3,
    'cars3d': 3
}
eval_datasets = {
    "shapes3d": dshapes3d.Dataset,
    "mpi_toy": dmpi3d.Dataset,
    "dsprites": ddsprit.Dataset,
    "cars3d": dcars3d.Dataset
}

dataset_transforms = {
    'custom': transforms.Compose([transforms.Resize(256), transforms.CenterCrop(256),
                                  transforms.ToTensor(),
                                  transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))]),
    'imagenet': transforms.Compose([transforms.Resize(256), transforms.CenterCrop(256),
                                    transforms.ToTensor(),
                                    transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))]),
    'cifar10': transforms.Compose([transforms.ToTensor(),
                                   transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))]),
    'shapes3d': transforms.Compose([transforms.ToTensor(),
                                    transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))]),
    'mnist': transforms.Compose([transforms.ToTensor(),
                                 transforms.Normalize((0.5), (0.5))]),
    'dsprites': transforms.Compose([transforms.ToTensor(),
                                    lambda x: 255. * x,
                                    transforms.Normalize((0.5), (0.5))]),
    'mpi_toy': transforms.Compose([transforms.ToTensor(),
                                   transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))]),
    'mpi_mid': transforms.Compose([transforms.ToTensor(),
                                   transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))]),
    'mpi_real': transforms.Compose([transforms.ToTensor(),
                                    transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))]),
    'clevr': transforms.Compose([transforms.Resize(64),
                                 transforms.ToTensor(),
                                 transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))]),
    'celebanpz': transforms.Compose([transforms.Resize(64),
                                     transforms.ToTensor(),
                                     transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))]),
    'celeba': transforms.Compose([transforms.Resize(64),
                                  transforms.ToTensor(),
                                  transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))]),
    'cars3d': transforms.Compose([transforms.Resize(64),
                                  transforms.ToTensor(),
                                  transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))]),
}


def return_shape(tensor, shape):
    return tensor.permute(0, 2, 1).view(-1, *shape[1:])


def gen_image(latents, energy_model, im_neg, flags, selected_idx=False):
    num_steps = flags.num_steps
    create_graph = flags.create_graph
    step_lr = flags.step_lr

    # latents list of Tensors shape (B, 1, D)
    im_negs = []
    im_neg.requires_grad_(requires_grad=True)
    for i in range(num_steps):
        energy = 0
        if selected_idx:
            energy = energy_model[selected_idx](im_neg, latents[0])
        else:
            for j in range(len(latents)):
                energy = energy_model[j % flags.components](im_neg, latents[j]) + energy
        im_grad, = torch.autograd.grad([energy.sum()], [im_neg], create_graph=create_graph)
        im_neg = im_neg - step_lr * im_grad

        im_negs.append(im_neg)
        im_neg = im_neg.detach()
        im_neg.requires_grad_()

    return im_neg, im_negs, im_grad


def decode_image(model, im_code, old_shape):
    pred = im_code
    _, cls_pred = pred.max(dim=-1)
    z_q = model.emb.weight[:, cls_pred].permute(1, 2, 0)
    z_q = return_shape(z_q, old_shape)
    img = model.decode(z_q)
    return img


class Flags():
    def __init__(self):
        pass


@gin.configurable
def get_train_flags(
        resume_iter,
        num_epochs,
        num_steps,
        step_lr,
        log_interval,
        save_interval,
        create_graph=True,
        without_ml=False,
        emb_loss=False,
        **kwargs):
    train_flags = Flags()
    train_flags.resume_iter = resume_iter
    train_flags.num_epochs = num_epochs
    train_flags.num_steps = num_steps
    train_flags.step_lr = step_lr
    train_flags.without_ml = without_ml

    train_flags.create_graph = create_graph
    train_flags.log_interval = log_interval
    train_flags.save_interval = save_interval
    train_flags.emb_loss = emb_loss

    for k, v in kwargs.items():
        train_flags.__setattr__(k, v)
    return train_flags


@gin.configurable
def get_test_flags(
        num_visuals,
        num_steps,
        step_lr,
        num_additional,
        create_graph=False,
        **kwargs
):
    test_flags = Flags()
    test_flags.num_visuals = num_visuals
    test_flags.num_steps = num_steps
    test_flags.step_lr = step_lr
    test_flags.num_additional = num_additional
    test_flags.create_graph = create_graph
    for k, v in kwargs.items():
        test_flags.__setattr__(k, v)

    return test_flags


@gin.configurable
def get_args(
        dataset_dir_name="",
        image_energy=False,
        joint_train=False,
        load_path=False,
        **kwargs
):
    args = Flags()
    for k, v in kwargs.items():
        args.__setattr__(k, v)
    args.dataset_dir_name = dataset_dir_name
    args.image_energy = image_energy
    args.joint_train = joint_train
    args.load_path = load_path
    return args


@gin.configurable
def get_model_args(
        model,
        hidden,
        k,
        num_channels,
        lr,
        lr_sche,
        **kwargs
):
    model_args = Flags()
    model_args.model = model
    model_args.hidden = hidden
    model_args.k = k
    model_args.num_channels = num_channels
    model_args.lr = lr
    model_args.lr_sche = lr_sche
    for k, v in kwargs.items():
        model_args.__setattr__(k, v)
    return model_args


def softmax_entropy(x: torch.Tensor) -> torch.Tensor:
    """Entropy of softmax distribution from logits."""
    return -(x.softmax(1) * x.log_softmax(1)).sum(1)


def train(train_loader, seg, model1, model2, decoder_model, latent_encoder, optimizer, eval_dataset, test_loader):
    train_flags = get_train_flags()
    train_flags.components = latent_encoder.components
    it = train_flags.resume_iter
    logdir = os.path.join(logger.get_dir(), "checkpoints")
    ce_loss = nn.CrossEntropyLoss()
    os.makedirs(os.path.expanduser(logdir), exist_ok=True)
    training_res = []
    val_res = []
    for epoch in range(train_flags.num_epochs):
        train_loss = train_ce_loss = train_dice_loss = val_loss = val_ce_loss = val_dice_loss = 0
        dice_0_t = dice_1_t = dice_2_t = dice_3_t = dice_1_v = dice_2_v = dice_3_v = dice_0_v = 0
        for batch_idx, (data, mask) in enumerate(train_loader):
            t1, t2 = data
            mask, one_hot_mask = mask
            # mask = np.array(mask)
            # #输出mask不同的值
            # print(np.unique(mask))
            bs = t1.shape[0]
            sample_mat = np.array([[i for i in range(bs) if i != j] for j in range(bs)])
            indexes = np.array([i for i in range(bs)])
            t1 = t1.cuda()
            t2 = t2.cuda()
            optimizer.zero_grad()
            with torch.no_grad():
                im_code_t1 = model1.encode(t1)
                im_code_t2 = model2.encode(t2)
                old_shape = im_code_t1.shape
            im_emb_t1, labels_t1 = model1.emb(im_code_t1.detach())
            im_emb_t2, labels_t2 = model2.emb(im_code_t2.detach())
            im_code_new_t1 = im_emb_t1.view(im_code_t1.shape[0], im_code_t1.shape[1], -1).permute(0, 2, 1)
            im_code_new_t2 = im_emb_t2.view(im_code_t2.shape[0], im_code_t2.shape[1], -1).permute(0, 2, 1)

            my_latents_t1 = latent_encoder(im_code_new_t1)
            my_latents_t2 = latent_encoder(im_code_new_t2)

            x = my_latents_t1
            y = my_latents_t2

            x = x.detach().cpu().numpy()
            y = y.detach().cpu().numpy()
            # numpy to list
            x = x.tolist()
            y = y.tolist()

            sim_all = []
            for i in range(len(x)):
                sim_list = []
                for j in range(len(x[0])):
                    x[i][j] = list(x[i][j])
                    y[i][j] = list(y[i][j])
                    # list to numpy
                    x[i][j] = np.array(x[i][j])
                    y[i][j] = np.array(y[i][j])
                    # numpy to tensor
                    x[i][j] = torch.from_numpy(x[i][j])
                    y[i][j] = torch.from_numpy(y[i][j])
                    # consine similarity
                    sim = torch.nn.functional.cosine_similarity(x[i][j], y[i][j], dim=0)
                    sim_list.append(sim)
                sim_all.append(sim_list)

            # sim list 排序
            index_list = []
            for i in range(len(sim_all)):
                index = []
                for j in range(len(sim_all[0])):
                    # 找出前400个最大值的索引
                    max_index = np.argsort(sim_all[i])[::-1][:400]

                index_list.append(max_index)

            x_sort = []
            y_sort = []

            for i in range(len(x)):
                x_1 = []
                y_1 = []
                for j in range(len(index_list[i])):
                    x_1.append(x[i][index_list[i][j]].numpy())
                    y_1.append(y[i][index_list[i][j]].numpy())

                x_sort.append(x_1)
                y_sort.append(y_1)

            t1_new = np.array(x_sort).astype(np.float32)
            t2_new = np.array(y_sort).astype(np.float32)
            t1_new_latent = torch.from_numpy(t1_new)
            t2_new_latent = torch.from_numpy(t2_new)

            t1_new_latent = t1_new_latent.cuda()
            t2_new_latent = t2_new_latent.cuda()

            t1_new_latent = t1_new_latent.view(t1_new_latent.shape[0], 20, 20, -1).permute(0, 3, 1, 2)
            source_out = seg(t1_new_latent)

            optimizer.zero_grad()
            mask = mask.squeeze(1)
            train_dice_loss, dice0, dice1, dice2, dice3 = softmax_dice()(source_out, mask.cuda())
            source_out = source_out.squeeze(1)
            mask = mask.squeeze(1)
            # train_ce_loss = CELoss()(source_out, mask.long().cuda())
            seg_loss = train_dice_loss
            seg_loss.backward()
            optimizer.step()

            train_loss += seg_loss
            dice_0_t += dice0.item()
            dice_1_t += dice1.item()
            dice_2_t += dice2.item()
            dice_3_t += dice3.item()



            log("Train", epoch, batch_idx + 1, seg_loss.item(), dice0.item(), dice1.item(), dice2.item(), dice3.item())
            writer.add_scalar('Train/loss', seg_loss.item(), epoch * len(train_loader) + i)
            writer.add_scalar('Train/Background Dice', dice0.item(), batch_idx)
            writer.add_scalar('Train/ET Dice', dice1.item(), batch_idx)
            writer.add_scalar('Train/TC Dice', dice2.item(), batch_idx)
            writer.add_scalar('Train/WT Dice', dice3.item(), batch_idx)

        d = len(train_loader)
        log("Train Average Epoch", epoch, batch_idx + 1, train_loss / d, dice_0_t / d , dice_1_t / d, dice_2_t / d , dice_3_t /d)
        writer.add_scalar('Train/loss/epoch', train_loss / d, epoch)
        writer.add_scalar('Train/BackGround Dice/epoch', dice_0_t / d, epoch)
        writer.add_scalar('Train/ET Dice/epoch', dice_1_t / d, epoch)
        writer.add_scalar('Train/TC Dice/epoch', dice_2_t / d, epoch)
        writer.add_scalar('Train/WT Dice/epoch', dice_3_t / d, epoch)
        training_res.append(round(train_loss / d, 3))
        dice_1_t = dice_2_t = dice_3_t = 0

        with torch.no_grad():
            model1.eval()
            model2.eval()
            seg.eval()
            for batch_idx, (data, mask) in enumerate(test_loader):
                t1, t2 = data
                mask, one_hot_mask = mask
                # mask = np.array(mask)
                # #输出mask不同的值
                # print(np.unique(mask))
                bs = t1.shape[0]
                sample_mat = np.array([[i for i in range(bs) if i != j] for j in range(bs)])
                indexes = np.array([i for i in range(bs)])
                t1 = t1.cuda()
                t2 = t2.cuda()
                optimizer.zero_grad()
                with torch.no_grad():
                    im_code_t1 = model1.encode(t1)
                    im_code_t2 = model2.encode(t2)
                    old_shape = im_code_t1.shape
                im_emb_t1, labels_t1 = model1.emb(im_code_t1.detach())
                im_emb_t2, labels_t2 = model2.emb(im_code_t2.detach())
                im_code_new_t1 = im_emb_t1.view(im_code_t1.shape[0], im_code_t1.shape[1], -1).permute(0, 2, 1)
                im_code_new_t2 = im_emb_t2.view(im_code_t2.shape[0], im_code_t2.shape[1], -1).permute(0, 2, 1)

                my_latents_t1 = latent_encoder(im_code_new_t1)
                my_latents_t2 = latent_encoder(im_code_new_t2)

                x = my_latents_t1
                y = my_latents_t2

                x = x.detach().cpu().numpy()
                y = y.detach().cpu().numpy()
                # numpy to list
                x = x.tolist()
                y = y.tolist()

                sim_all = []
                for i in range(len(x)):
                    sim_list = []
                    for j in range(len(x[0])):
                        x[i][j] = list(x[i][j])
                        y[i][j] = list(y[i][j])
                        # list to numpy
                        x[i][j] = np.array(x[i][j])
                        y[i][j] = np.array(y[i][j])
                        # numpy to tensor
                        x[i][j] = torch.from_numpy(x[i][j])
                        y[i][j] = torch.from_numpy(y[i][j])
                        # consine similarity
                        sim = torch.nn.functional.cosine_similarity(x[i][j], y[i][j], dim=0)
                        sim_list.append(sim)
                    sim_all.append(sim_list)

                # sim list 排序
                index_list = []
                for i in range(len(sim_all)):
                    index = []
                    for j in range(len(sim_all[0])):
                        # 找出前400个最大值的索引
                        max_index = np.argsort(sim_all[i])[::-1][:400]

                    index_list.append(max_index)

                x_sort = []
                y_sort = []

                for i in range(len(x)):
                    x_1 = []
                    y_1 = []
                    for j in range(len(index_list[i])):
                        x_1.append(x[i][index_list[i][j]].numpy())
                        y_1.append(y[i][index_list[i][j]].numpy())

                    x_sort.append(x_1)
                    y_sort.append(y_1)

                t1_new = np.array(x_sort).astype(np.float32)
                t2_new = np.array(y_sort).astype(np.float32)
                t1_new_latent = torch.from_numpy(t1_new)
                t2_new_latent = torch.from_numpy(t2_new)

                t1_new_latent = t1_new_latent.cuda()
                t2_new_latent = t2_new_latent.cuda()

                source_out = seg(t1_new_latent)

                mask = mask.squeeze(1)
                val_dice_loss, dice0, dice1, dice2, dice3 = softmax_dice()(source_out, mask.cuda())
                # val_ce_loss = CELoss()(source_out, mask.long().cuda())
                seg_loss = train_dice_loss
                val_loss += seg_loss
                dice_0_v += dice0.item()
                dice_1_v += dice1.item()
                dice_2_v += dice2.item()
                dice_3_v += dice3.item()

                if (batch_idx % 10 == 0):
                    log("Val", epoch, batch_idx + 1, seg_loss.item(), dice0.item(), dice1.item(), dice2.item(), dice3.item())

        d = len(test_loader)
        log("Val Average Epoch", epoch, batch_idx + 1, val_loss.item() / d, dice_0_t / d, dice_1_t / d, dice_2_t / d, dice_3_t / d)
        writer.add_scalar('val/train loss', val_loss.item() / d, epoch)
        writer.add_scalar('val/Background Dice', dice_0_t / d, epoch)
        writer.add_scalar('val/ET Dice', dice_1_t / d, epoch)
        writer.add_scalar('val/TC Dice', dice_2_t / d, epoch)
        writer.add_scalar('val/WT Dice', dice_3_t / d, epoch)
        val_res.append(round(val_loss.item() / d, 3))




def random_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True

def make_loader(data_dir, batch_size):
    patient_list = {}
    base_dir = '/home1/jkwang/dataset/BraTS192D/img'
    patient_list['t1'] = []
    patient_list['t2'] = []
    patient_list['mask'] = []
    for dir in os.listdir(base_dir):
        t1_dir_path = os.path.join(base_dir, dir, 't1')
        t2_dir_path = os.path.join(base_dir, dir, 't2')
        mask_dir_path = os.path.join(base_dir, dir, 'mask')
        for file in os.listdir(t1_dir_path):
            patient_list['t1'].append(os.path.join(t1_dir_path, file))
        for file in os.listdir(t2_dir_path):
            patient_list['t2'].append(os.path.join(t2_dir_path, file))
        for file in os.listdir(mask_dir_path):
            patient_list['mask'].append(os.path.join(mask_dir_path, file))

    #split train val test
    train_t1 = patient_list['t1'][:int(len(patient_list['t1'])*0.8)]
    train_t2 = patient_list['t2'][:int(len(patient_list['t2'])*0.8)]
    train_mask = patient_list['mask'][:int(len(patient_list['mask'])*0.8)]
    # val_t1 = patient_list['t1'][int(len(patient_list['t1'])*0.8):int(len(patient_list['t1'])*0.9)]
    # val_t2 = patient_list['t2'][int(len(patient_list['t2'])*0.8):int(len(patient_list['t2'])*0.9)]
    # val_mask = patient_list['mask'][int(len(patient_list['mask'])*0.8):int(len(patient_list['mask'])*0.9)]
    test_t1 = patient_list['t1'][int(len(patient_list['t1'])*0.8):]
    test_t2 = patient_list['t2'][int(len(patient_list['t2'])*0.8):]
    test_mask = patient_list['mask'][int(len(patient_list['mask'])*0.8):]

    import data_loader
    t1_train_dataset = data_loader.BraTS_2D_dataset(train_t1, train_mask, augment=False)
    t1_train_dataloader = torch.utils.data.DataLoader(t1_train_dataset, batch_size=batch_size, shuffle=True, num_workers=0, pin_memory=True)

    t1_test_dataset = data_loader.BraTS_2D_dataset(test_t1, test_mask, augment=False)
    t1_test_dataloader = torch.utils.data.DataLoader(t1_test_dataset, batch_size=batch_size, shuffle=True, num_workers=0, pin_memory=True)

    t2_train_dataset = data_loader.BraTS_2D_dataset(train_t2, train_mask, augment=False)
    t2_train_dataloader = torch.utils.data.DataLoader(t2_train_dataset, batch_size=batch_size, shuffle=True, num_workers=0, pin_memory=True)

    t2_test_dataset = data_loader.BraTS_2D_dataset(test_t2, test_mask, augment=False)
    t2_test_dataloader = torch.utils.data.DataLoader(t2_test_dataset, batch_size=batch_size, shuffle=True, num_workers=0, pin_memory=True)


    train_all_dataset = data_loader.BraTS_2D_all_dataset(train_t1, train_t2, train_mask, augment=False)
    train_all_dataloader = torch.utils.data.DataLoader(train_all_dataset, batch_size=batch_size, shuffle=True, num_workers=0, pin_memory=True)

    test_all_dataset = data_loader.BraTS_2D_all_dataset(test_t1, test_t2, test_mask, augment=False)
    test_all_dataloader = torch.utils.data.DataLoader(test_all_dataset, batch_size=batch_size, shuffle=True, num_workers=0, pin_memory=True)

    return train_all_dataloader, test_all_dataset, test_all_dataloader


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="training codes")
    parser.add_argument("--debug", type=bool, default=False,
                        help="debug mode or not")
    parser.add_argument("--config", type=str, default="configs/brats_t1_ce.gin",
                        help="config file path")
    parser.add_argument("--enc_model", type=str, default="sc_decoder",
                        help="config file path")
    parser.add_argument("--wo_dis_loss", type=bool, default=True,
                        help="config settings")
    parser.add_argument("--batch_size", type=int, default=-1,
                        help="config settings")
    parser.add_argument("--concepts_num", type=int, default=20,
                        help="config settings")
    parser.add_argument("--seed", type=int, default=-1,
                        help="config settings")
    meta_args = parser.parse_args()
    time = datetime.datetime.now().strftime("exp" + (f"_cn{meta_args.concepts_num}_") + (
        f"_b{meta_args.batch_size}_" if not meta_args.batch_size == -1 else "") + (
                                                "wo_dis_" if meta_args.wo_dis_loss else "") + meta_args.enc_model + "-%Y-%m-%d-%H-%M-%S-%f")
    if meta_args.enc_model == "sc_decoder":
        from models.vct_brats import VCT_Decoder, VCT_Encoder
    else:
        assert NotImplemented
    gin.parse_config_file(meta_args.config)
    if meta_args.seed == -1:
        seed = np.random.randint(1e6)
    else:
        seed = meta_args.seed
    random_seed(51)
    args = get_args()
    gin.constant('num_steps', args.num_steps)
    gin.constant('step_lr', args.step_lr)
    gin.constant('image_energy', args.image_energy)
    gin.parse_config_file(f"configs/{args.name}_shared.gin")

    if not meta_args.wo_dis_loss:
        gin.bind_parameter("get_train_flags.dis_loss", True)
    else:
        gin.bind_parameter("get_train_flags.dis_loss", False)

    logger.configure(out_dir="%s_dis_exp" % args.name, debug=meta_args.debug, time=time)
    logger.log(f"seed:{seed}")
    logger.log(meta_args.config)

    writer = SummaryWriter(log_dir="%s_dis_exp" % args.name + "/" + 'tensorboard' + "/" + time)
    model_args = get_model_args()
    model1 = VQ_CVAE(model_args.hidden, k=model_args.k, num_channels=model_args.num_channels)
    model1.cuda()
    # load
    model1.load_state_dict(torch.load(model_args.path, map_location='cpu'))

    model2 = VQ_CVAE(model_args.hidden, k=model_args.k, num_channels=model_args.num_channels)
    model2.cuda()
    # load
    model2.load_state_dict(torch.load('/home1/jkwang/code/da/VCT/results_t2/2022-11-22_05-21-03/checkpoints/model_200.pth', map_location='cpu'))

    vct_enc = VCT_Encoder(z_index_dim=1600)
    vct_dec = VCT_Decoder(index_num=model_args.k, z_index_dim=model_args.shape_num, ce_loss=True)

    vct_enc.cuda()
    vct_dec.cuda()

    seg = DeepLabHeadV3Plus(in_channels=256, low_level_channels=256, num_classes=4)
    seg.cuda()

    model1.joint_train = args.joint_train
    model1.eval()

    model2.joint_train = args.joint_train
    model2.eval()
    for p in model1.parameters():
        p.requires_grad_(False)
    optimizer = optim.Adam(itertools.chain(vct_enc.parameters(), vct_dec.parameters()), lr=model_args.lr)
    for p in model2.parameters():
        p.requires_grad_(False)

    if args.load_path:
        vct_enc.load_state_dict(torch.load(args.load_path)['encoder_model_state_dict'])
        vct_dec.load_state_dict(torch.load(args.load_path)['decoder_model_state_dict'])

    # kwargs = {'num_workers': 8, 'pin_memory': True}
    # dataset_train_dir = os.path.join(args.data_dir, args.name)
    # dataset_test_dir = os.path.join(args.data_dir, args.name)
    # if args.name in ['imagenet', 'custom']:
    #     dataset_train_dir = os.path.join(dataset_train_dir, 'train')
    #     dataset_test_dir = os.path.join(dataset_test_dir, 'val')
    # train_dataset = datasets_classes[args.name](dataset_train_dir,
    #                                             transform=dataset_transforms[args.name],
    #                                             **dataset_train_args[args.name])
    # if args.name in ['mnist']:
    #     train_dataset.eval_flag = False
    # train_loader1 = torch.utils.data.DataLoader(
    #     train_dataset,
    #     batch_size=(args.batch_size if meta_args.batch_size == -1 else meta_args.batch_size), shuffle=True, **kwargs)
    train_dir = '/home1/jkwang/dataset/BraTS192D/img'
    train_loader, eval_dataset, test_loader = make_loader(data_dir=train_dir, batch_size=args.batch_size)
    train(train_loader, seg, model1, model2, vct_dec, vct_enc, optimizer, eval_dataset, test_loader)