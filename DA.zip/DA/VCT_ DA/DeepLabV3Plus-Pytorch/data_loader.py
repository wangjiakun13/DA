import torch
import torch.utils.data
from torch.utils.data import Dataset
import albumentations as A
import torchio as tio
import random
from random import shuffle
from PIL import Image
import torch.nn.functional as F
import numpy as np
import os
import utils.helper as helper

palette = [[0], [1], [2], [3]]  # 原始mask中不同类别的标记的颜色值
custom_palette = [[0, 0, 0], [255, 255, 255], [101, 12, 68], [68, 104, 118]]  # 将mask重新映射为自定义的颜色（彩色方便观察）

from torchvision import transforms


def partitioning(patients_list, split_ratio):
    part = {'train': [], 'valid': [], 'test': []}
    random.shuffle(patients_list)
    l = len(patients_list)
    split_pt = [int(split_ratio[0] * l), int((split_ratio[0] + split_ratio[1]) * l)]
    part['train'] = patients_list[:split_pt[0]]
    part['valid'] = patients_list[split_pt[0]:split_pt[1]]
    part['test'] = patients_list[split_pt[1]:]
    print('train: ', len(part['train']), ' ', 'valid: ', len(part['valid']), ' ', 'test: ', len(part['test']))
    return part

class BraTS_2D_all_dataset(Dataset):
    def __init__(self, partition, augment=False):
        self.t1 = partition['T1']
        self.t2 = partition['T2']
        self.mask = partition['Masks']
        self.augment = augment

        self.aug = A.Compose([
            A.OneOf([
                A.Rotate(limit=15),
                A.VerticalFlip()], p=0.7),
            A.PadIfNeeded(min_height=256, min_width=256, p=1),
            A.GridDistortion(p=0.5)])

    def __len__(self):
        return (len(self.t1))

    def __getitem__(self, idx):
        # Generate one batch of data
        t1 = Image.open(self.t1[idx])
        t2 = Image.open(self.t2[idx])
        mask = Image.open(self.mask[idx])
        t1 = np.array(t1)
        t2 = np.array(t2)
        t1 = np.expand_dims(t1, axis=2)
        t2 = np.expand_dims(t2, axis=2)
        mask = np.array(mask)

        mask[mask == 4] = 1
        mask[mask == 2] = 1
        mask[mask == 1] = 1
        # mask = np.expand_dims(mask, axis=2)
        # one_hot_mask = helper.mask_to_onehot(mask, palette)
        one_hot_mask = mask

        t1 = transforms.ToTensor()(t1)
        t2 = transforms.ToTensor()(t2)
        t1 = t1.type(torch.FloatTensor)
        t2 = t2.type(torch.FloatTensor)
        # mask = mask.transpose(2, 0, 1)
        mask = torch.as_tensor(mask, dtype=torch.int64)

        data_list = [t1, t2]
        mask_list = [mask, one_hot_mask]

        return data_list, mask



class BraTS_2D_dataset(Dataset):
    def __init__(self, img, mask, augment=False):
        self.img = img
        self.mask = mask
        self.augment = augment

        self.aug = A.Compose([
            A.OneOf([
                A.Rotate(limit=15),
                A.VerticalFlip()], p=0.7),
            A.PadIfNeeded(min_height=256, min_width=256, p=1),
            A.GridDistortion(p=0.5)])

    def __len__(self):
        return (len(self.img))

    def __getitem__(self, idx):
        # Generate one batch of data
        image = Image.open(self.img[idx])
        mask = Image.open(self.mask[idx])
        image = np.array(image)
        mask = np.array(mask)
        t1 = transforms.ToTensor()
        if self.augment:
            augmented = self.aug(image=image, mask=mask)
            image = t1(augmented['image'])
            """
            https://pytorch.org/docs/stable/torchvision/transforms.html
            Because the input image is scaled to [0.0, 1.0], totensor 
            transformation should not be used when transforming target 
            image masks.
            https://github.com/pytorch/vision/blob/master/references/segmentation/\
            transforms.py
            """
            mask = torch.as_tensor(augmented['mask'])
        else:
            image = t1(image)
            mask = torch.as_tensor(mask)

        mask = torch.unsqueeze(mask, 0)
        image = image.type(torch.FloatTensor)
        # note that mask is integer
        mask = mask.type(torch.IntTensor)

        # Return image and mask pair tensors
        return image, mask


class CreateOneHotMask:
    def __init__(self, num_classes):
        self.num_classes = num_classes

    def __call__(self, sample):
        mask = sample
        one_hot_mask = torch.zeros((self.num_classes, *mask.shape))
        for i in range(self.num_classes):
            one_hot_mask[i][mask == i] = 1
        return one_hot_mask