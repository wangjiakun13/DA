import glob
from datetime import datetime

import pandas as pd
import torchvision
from IPython import get_ipython
from torch.utils.data import DataLoader
from torchaudio import transforms
from tqdm import tqdm
import network
import utils
import os
import random
import argparse
import numpy as np


from utils.loss import *

import torch
import torch.nn as nn
from utils.visualizer import Visualizer

from PIL import Image
import matplotlib
import matplotlib.pyplot as plt

from utils.loss import SoftDiceLoss

os.environ["CUDA_VISIBLE_DEVICES"] = "2"

from tensorboardX import SummaryWriter
def get_argparser():
    parser = argparse.ArgumentParser()

    # Datset Options
    parser.add_argument("--data_root", type=str, default='./datasets/data',
                        help="path to Dataset")

    parser.add_argument("--num_classes", type=int, default=2,
                        help="num classes (default: None)")

    # Deeplab Options
    available_models = sorted(name for name in network.modeling.__dict__ if name.islower() and \
                              not (name.startswith("__") or name.startswith('_')) and callable(
                              network.modeling.__dict__[name])
                              )
    parser.add_argument("--model", type=str, default='deeplabv3plus_resnet101',
                        choices=available_models, help='model name')
    parser.add_argument("--separable_conv", action='store_true', default=False,
                        help="apply separable conv to decoder and aspp")
    parser.add_argument("--output_stride", type=int, default=16, choices=[8, 16])

    # Train Options
    parser.add_argument("--test_only", action='store_true', default=False)
    parser.add_argument('--n_epochs', type=int, default=200, help='number of epochs of training')
    parser.add_argument("--save_val_results", action='store_true', default=False,
                        help="save segmentation results to \"./results\"")
    parser.add_argument("--total_itrs", type=int, default=30e4,
                        help="epoch number (default: 300k)")
    parser.add_argument("--lr", type=float, default=0.01,
                        help="learning rate (default: 0.01)")
    parser.add_argument("--lr_policy", type=str, default='poly', choices=['poly', 'step'],
                        help="learning rate scheduler policy")
    parser.add_argument("--step_size", type=int, default=10000)
    parser.add_argument("--crop_val", action='store_true', default=False,
                        help='crop validation (default: False)')
    parser.add_argument("--batch_size", type=int, default=128,
                        help='batch size (default: 16)')
    parser.add_argument("--val_batch_size", type=int, default=4,
                        help='batch size for validation (default: 4)')
    parser.add_argument("--crop_size", type=int, default=513)

    parser.add_argument("--ckpt", default=None, type=str,
                        help="restore from checkpoint")
    parser.add_argument("--continue_training", action='store_true', default=False)

    parser.add_argument("--loss_type", type=str, default='cross_entropy',
                        choices=['cross_entropy', 'focal_loss'], help="loss type (default: False)")
    parser.add_argument("--gpu_id", type=str, default='2',
                        help="GPU ID")
    parser.add_argument("--weight_decay", type=float, default=1e-4,
                        help='weight decay (default: 1e-4)')
    parser.add_argument("--random_seed", type=int, default=1,
                        help="random seed (default: 1)")
    parser.add_argument("--print_interval", type=int, default=10,
                        help="print interval of loss (default: 10)")
    parser.add_argument("--val_interval", type=int, default=100,
                        help="epoch interval for eval (default: 100)")
    parser.add_argument("--download", action='store_true', default=False,
                        help="download datasets")

    # PASCAL VOC Options
    parser.add_argument("--year", type=str, default='2012',
                        choices=['2012_aug', '2012', '2011', '2009', '2008', '2007'], help='year of VOC')

    # Visdom options
    parser.add_argument("--enable_vis", action='store_true', default=True,
                        help="use visdom for visualization")
    parser.add_argument("--vis_port", type=str, default='8097',
                        help='port for visdom')
    parser.add_argument("--vis_env", type=str, default='main',
                        help='env for visdom')
    parser.add_argument("--vis_num_samples", type=int, default=8,
                        help='number of samples for visualization (default: 8)')
    return parser




def make_loader(batch_size):

    base_dir = '/home1/jkwang/dataset/BraTS192D/img'

    patient_path_list = {}
    patient_path_list['T1'] = {}
    patient_path_list['T2'] = {}
    patient_path_list['Masks'] = {}
    patient_image_cnt_T1 = {}
    patient_image_cnt_T2 = {}
    patient_image_cnt_Mask = {}
    for dir in os.listdir(base_dir):
        patient_path_list['T1'][dir] = sorted(glob.glob(os.path.join(base_dir, dir, 't1', '*.png')))
        patient_image_cnt_T1[dir] = len(patient_path_list['T1'][dir])
        patient_path_list['T2'][dir] = sorted(glob.glob(os.path.join(base_dir, dir, 't2', '*.png')))
        patient_image_cnt_T2[dir] = len(patient_path_list['T2'][dir])
        patient_path_list['Masks'][dir] = sorted(glob.glob(os.path.join(base_dir, dir, 'mask', '*.png')))
        patient_image_cnt_Mask[dir] = len(patient_path_list['Masks'][dir])

    keys_to_delete = [k for k in patient_image_cnt_T1 if
                      patient_image_cnt_T1[k] != patient_image_cnt_Mask[k] or patient_image_cnt_T1[k] == 0
                      or patient_image_cnt_Mask[k] == 0]
    for k in keys_to_delete:
        del patient_image_cnt_T1[k], patient_image_cnt_Mask[k], patient_path_list['T1'][k], \
            patient_path_list['Masks'][k], patient_image_cnt_T2[k], patient_path_list['T2'][k]
    import data_loader
    part = data_loader.partitioning([*patient_image_cnt_T1.keys()], split_ratio=[0.7, 0.2, 0.1])
    partition_train = {}
    partition_train['T1'] = []
    partition_train['T2'] = []
    partition_train['Masks'] = []
    for p in part['train']:
        partition_train['T1'].extend(patient_path_list['T1'][p])
        partition_train['T2'].extend(patient_path_list['T2'][p])
        partition_train['Masks'].extend(patient_path_list['Masks'][p])
    partition_val = {}
    partition_val['T1'] = []
    partition_val['T2'] = []
    partition_val['Masks'] = []
    for p in part['valid']:
        partition_val['T1'].extend(patient_path_list['T1'][p])
        partition_val['T2'].extend(patient_path_list['T2'][p])
        partition_val['Masks'].extend(patient_path_list['Masks'][p])
    partition_test = {}
    partition_test['T1'] = []
    partition_test['T2'] = []
    partition_test['Masks'] = []
    for p in part['test']:
        partition_test['T1'].extend(patient_path_list['T1'][p])
        partition_test['T2'].extend(patient_path_list['T2'][p])
        partition_test['Masks'].extend(patient_path_list['Masks'][p])

    train_dataset = data_loader.BraTS_2D_all_dataset(partition_train, augment=False)
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=1)
    val_dataset = data_loader.BraTS_2D_all_dataset(partition_val, augment=False)
    val_loader =  DataLoader(val_dataset, batch_size=batch_size, shuffle=False, num_workers=1)
    test_dataset = data_loader.BraTS_2D_all_dataset(partition_test, augment=False)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False, num_workers=1)
    return train_loader, val_loader, test_loader

def set_seed(seed):
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = True

def main():

    writer = SummaryWriter(logdir='runs/{}'.format(datetime.now().strftime('%b%d_%H-%M-%S')))

    threshold = 0.5
    args = get_argparser().parse_args()

    set_seed(51)

    model = network.UNet_2D(1, 1, 32, 0.2)
    model.cuda()

    train_loader, val_loader, test_loader = make_loader(args.batch_size)

    criterion = DiceLoss().cuda()

    optimizer = torch.optim.Adam(model.parameters(), lr=1e-4)

    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.n_epochs, eta_min=1e-6)

    train_on_gpu = torch.cuda.is_available()

    model = train(args, args.n_epochs,
                     train_loader,
                     val_loader,
                     model,
                     optimizer,
                     criterion,
                     train_on_gpu,
                     performance_metrics,
                     'model.pt',
                     threshold,
                  writer)



def train(args, n_epochs, train_loader, val_loader, model, optimizer, criterion, train_on_gpu, performance_metrics,
             path, threshold, writer):
    # keep track of loss and performance merics
    loss_and_metrics = []
    # initialize tracker for max DSC
    DSC_max = 0
    show_every = 50
    # epoch training loop
    path = os.path.join('/home1/jkwang/code/da/VCT_ DA/DeepLabV3Plus-pytorch/unet_results')
    if not os.path.exists(path):
        os.makedirs(path)
    for epoch in tqdm(range(1, n_epochs + 1), total=n_epochs + 1):
        print(f'=== Epoch #{epoch} ===')
        # initialize variables to monitor training and validation loss, and performance metrics
        train_loss = 0.0
        valid_loss = 0.0
        specificity_val = 0
        sensitivity_val = 0
        precision_val = 0
        F1_score_val = 0
        F2_score_val = 0
        DSC_val = 0
        valid_cnt = 0
        ###################
        # train the model #
        ###################
        model.train()
        print('=== Training ===')
        # batch training loop
        for batch_idx, (data, target) in enumerate(train_loader):
            # move to GPU
            if train_on_gpu:
                t1, t2 = data
                t1 = t1.cuda()
                t2 = t2.cuda()
                target = target.cuda()
            if batch_idx % show_every == 0:
                print(f'{batch_idx + 1} / {len(train_loader)}...')

            # clear the gradients of all optimized variable
            optimizer.zero_grad()
            # forward pass (inference) to get the output
            output = model(t1)
            # calculate the batch loss
            loss = criterion(output, target)
            # backpropagation
            loss.backward()
            # Update weights
            optimizer.step()
            # update training loss
            train_loss += ((1 / (batch_idx + 1)) * (loss.data - train_loss))

            ######################
        # validate the model #
        ######################
        print('=== Validation ===')
        # Set the model to inference mode
        model.eval()
        with torch.no_grad():
            # batch training loop
            for batch_idx, (data, target) in enumerate(val_loader):
                if batch_idx % show_every == 0:
                    print(f'{batch_idx + 1} / {len(val_loader)}...')
                # move to GPU
                if train_on_gpu:
                    t1, t2 = data
                    t1 = t1.cuda()
                    t2 = t2.cuda()
                    target = target.cuda()
                # forward pass (inference) to get the output
                output = model(t1)
                # calculate the batch loss
                loss = criterion(output, target)
                # update validation loss
                valid_loss += ((1 / (batch_idx + 1)) * (loss.data - valid_loss))
                # convert output probabilities to predicted class
                output = output.cpu().detach().numpy()
                # Binarize the output
                output_b = (output > threshold) * 1
                output_b = np.squeeze(output_b)
                batch_l = output_b.size
                # update the total number of validation pairs
                valid_cnt += batch_l
                t1 = torchvision.transforms.ToTensor()
                # Transform output back to Pytorch Tensor and move it to GPU
                output_b = t1(output_b)
                output_b = output_b.cuda()
                # calculate average performance metrics per batches
                m = performance_metrics(smooth=1e-6)
                specificity, sensitivity, precision, F1_score, F2_score, DSC = m(output_b, target)

                specificity_val += specificity * batch_l
                sensitivity_val += sensitivity * batch_l
                precision_val += precision * batch_l
                F1_score_val += F1_score * batch_l
                F2_score_val += F2_score * batch_l
                DSC_val += DSC * batch_l
                # Calculate the overall average metrics
        specificity_val, sensitivity_val, precision_val, F1_score_val, F2_score_val, DSC_val = specificity_val / valid_cnt, sensitivity_val / valid_cnt, precision_val / valid_cnt, F1_score_val / valid_cnt, F2_score_val / valid_cnt, DSC_val / valid_cnt

        # print training/validation statistics
        print('Epoch: {} \tTraining Loss: {:.4f} \tValidation Loss: {:.4f}'.format(
            epoch,
            train_loss,
            valid_loss
        ))
        writer.add_scalar('Train Loss', train_loss, epoch)
        writer.add_scalar('Valid Loss', valid_loss, epoch)
        print('Specificity: {:.6f} \tSensitivity: {:.6f} \tF2_score: {:.6f} \tDSC: {:.6f}'.format(
            specificity_val,
            sensitivity_val,
            F2_score_val,
            DSC_val
        ))
        writer.add_scalar('Dice', DSC_val, epoch)
        if DSC_val > DSC_max:
            print('Validation DSC increased.  Saving model ...')
            torch.save(model.state_dict(), os.path.join(path, 'epoch' + str(epoch) + '_checkpoint.pth'))
            DSC_max = DSC_val

        loss_and_metrics.append((epoch, train_loss.cpu().detach().numpy(), valid_loss.cpu().detach().numpy(),
                                 specificity_val, sensitivity_val, precision_val, F1_score_val, F2_score_val, DSC_val))

    # save the loss_epoch and performance metrics history

    torch.save(model.state_dict(), os.path.join(path, 'final.pth'))
    # return trained model
    return model

if __name__ == '__main__':
    main()
