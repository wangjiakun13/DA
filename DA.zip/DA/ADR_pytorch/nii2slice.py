import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from tqdm import tqdm
from torch_lr_finder import LRFinder
import albumentations as A
import torchio as tio
import SimpleITK as sitk
import os
import nibabel as nib
import numpy as np

dir_list = []
path = '/home1/jkwang/dataset/MMWHS'

# for i in range(1, 21):
#     patient_label = i
#     path = os.path.join(pth, 'ct_train', str(patient_label))
#     dir_list.append(path)
#
# for dir in dir_list:
#     p = dir + '/Masks'
#     os.makedirs(p)
#     p = dir + '/CT'
#     os.makedirs(p)

for i in range(1001, 1021):
    patient_label = i
    pth = os.path.join(path, 'ct_train', 'ct_train_' + str(patient_label) + '_label.nii.gz')
    img = nib.load(pth)
    img_data = img.get_data()
    for s in range(img_data.shape[2]):
        slice_label = '{:03d}'.format(s+1)
        slice_img = img_data[:,:,s]
        slice_pth = os.path.join(path, 'ct_train', str(patient_label-1000), 'Masks', 'M_' + slice_label)
        np.save(slice_pth, slice_img)