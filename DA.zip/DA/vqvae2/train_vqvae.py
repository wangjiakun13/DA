import argparse
import glob
import os
import numpy as np
import torch
from torch import nn, optim
from torch.utils.data import DataLoader
from torch.autograd import Variable
from tqdm import tqdm
from networks import VQVAE
from utilities import ChestXrayHDF5, recon_image, save_loss_plots
from data_loader import *

cuda = True if torch.cuda.is_available() else False
Tensor = torch.cuda.FloatTensor if cuda else torch.FloatTensor

parser = argparse.ArgumentParser()
parser.add_argument('--size', type=int, default=256)
parser.add_argument('--n_epochs', type=int, default=5600)
parser.add_argument('--lr', type=float, default=6e-4)
parser.add_argument('--first_stride', type=int, default=4, help="2, 4, 8, or 16")
parser.add_argument('--second_stride', type=int, default=2, help="2, 4, 8, or 16")
parser.add_argument('--embed_dim', type=int, default=64)
parser.add_argument('--data_path', type=str, default='/home1/jkwang/dataset/')
parser.add_argument('--dataset', type=str, default='MMWHS', help="CheXpert or mimic")
parser.add_argument('--view', type=str, default='frontal', help="frontal or lateral")
parser.add_argument('--save_path', type=str, default='/home1/jkwang/code/da/vqvae2/results')
parser.add_argument('--train_run', type=str, default='0')
args = parser.parse_args()
torch.manual_seed(816)

save_path = f'{args.save_path}/{args.dataset}/{args.train_run}'
os.makedirs(save_path, exist_ok=True)
os.makedirs(f'{save_path}/checkpoint/', exist_ok=True)
os.makedirs(f'{save_path}/sample/', exist_ok=True)
with open(f'{save_path}/args.txt', 'w') as f:
    for key in vars(args).keys():
        f.write(f'{key}: {vars(args)[key]}\n')
        print(f'{key}: {vars(args)[key]}')

    source_path_list = {}
    source_path_list['CT'] = {}
    source_path_list['Masks'] = {}
    source_image_cnt = {}
    source_mask_cnt = {}

    for i in range(1, 21):
        patient_label = i
        source_path_list['CT']['Patient' + str(patient_label)] = sorted(
            glob.glob('/home1/jkwang/dataset/MMWHS/ct_train' + '/' + str(patient_label) + '/CT/*.npy'))
        source_image_cnt['Patient' + str(patient_label)] = len(
            source_path_list['CT']['Patient' + str(patient_label)])
        source_path_list['Masks']['Patient' + str(patient_label)] = sorted(
            glob.glob('/home1/jkwang/dataset/MMWHS/ct_train' + '/' + str(patient_label) + '/Masks/*.npy'))
        source_mask_cnt['Patient' + str(patient_label)] = len(
            source_path_list['Masks']['Patient' + str(patient_label)])

    keys_to_delete = [k for k in source_image_cnt if
                      source_image_cnt[k] != source_mask_cnt[k] or source_image_cnt[k] == 0
                      or source_mask_cnt[k] == 0]

    for k in keys_to_delete:
        del source_image_cnt[k], source_mask_cnt[k], source_path_list['CT'][k], \
            source_path_list['Masks'][k]

    source_part = partitioning([*source_image_cnt.keys()], split_ratio=[0.8, 0.1, 0.1])
    source_partition_train = {}
    source_partition_train['CT'] = []
    source_partition_train['Masks'] = []
    for p in source_part['train']:
        source_partition_train['CT'].extend(source_path_list['CT'][p])
        source_partition_train['Masks'].extend(source_path_list['Masks'][p])
    source_partition_valid = {}
    source_partition_valid['CT'] = []
    source_partition_valid['Masks'] = []
    for p in source_part['valid']:
        source_partition_valid['CT'].extend(source_path_list['CT'][p])
        source_partition_valid['Masks'].extend(source_path_list['Masks'][p])
    source_partition_test = {}
    for p in source_part['test']:
        source_partition_test[p] = {}
        source_partition_test[p]['CT'] = []
        source_partition_test[p]['Masks'] = []
        source_partition_test[p]['CT'].extend(source_path_list['CT'][p])
        source_partition_test[p]['Masks'].extend(source_path_list['Masks'][p])

    source_dataset_train = MM_2D_dataset_source(source_partition_train, augment=False)
    source_dataset_valid = MM_2D_dataset_source(source_partition_valid, augment=False)
    source_dataset_test = {}

    source_loaders = {}
    for p in source_partition_test:
        source_dataset_test[p] = MM_2D_dataset_source(source_partition_test[p], augment=False)
    source_loaders['train'] = torch.utils.data.DataLoader(source_dataset_train,
                                                          batch_size=128,
                                                          shuffle=True,
                                                          num_workers=4)
    source_loaders['valid'] = torch.utils.data.DataLoader(source_dataset_valid,
                                                          batch_size=128,
                                                          shuffle=False,
                                                          num_workers=4)
for i, (img, targets) in enumerate(source_loaders['valid']):
    sample_img = Variable(img.type(Tensor))
    break


if cuda:
    model = VQVAE(first_stride=args.first_stride, second_stride=args.second_stride, embed_dim=args.embed_dim).cuda()
else:
    model = VQVAE(first_stride=args.first_stride, second_stride=args.second_stride, embed_dim=args.embed_dim)
n_gpu = torch.cuda.device_count()
if n_gpu > 1:
    device_ids = list(range(n_gpu))
    model = nn.DataParallel(model, device_ids=device_ids)

optimizer = optim.Adam(model.parameters(), lr=args.lr)

losses = np.zeros((2, args.n_epochs, 3))  # [0,:,:] index for train, [1,:,:] index for valid

for epoch in range(args.n_epochs):
    for phase in ['train', 'valid']:
        model.train(phase == 'train')  # True when 'train', False when 'valid'
        criterion = nn.MSELoss()

        latent_loss_weight = 0.25
        n_row = 5
        loader = tqdm(source_loaders[phase])
        for i, (img, label) in enumerate(                                              v                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       ):
            img = Variable(img.type(Tensor))
            with torch.set_grad_enabled(phase == 'train'):
                optimizer.zero_grad()
                out, latent_loss = model(img)
                recon_loss = criterion(out, img)
                latent_loss = latent_loss.mean()
                loss = recon_loss + latent_loss_weight * latent_loss
                if phase == 'train':
                    loss.backward()
                    optimizer.step()
                    losses[0, epoch, :] = [loss.cpu().detach().numpy(), recon_loss.cpu().detach().numpy(), latent_loss.cpu().detach().numpy()]
                else:
                    losses[1, epoch, :] = [loss.cpu().detach().numpy(), recon_loss.cpu().detach().numpy(), latent_loss.cpu().detach().numpy()]
                lr = optimizer.param_groups[0]['lr']

            loader.set_description((f'phase: {phase}; epoch: {epoch + 1}; total_loss: {loss.item():.5f}; '
                                    f'latent: {latent_loss.item():.5f}; mse: {recon_loss.item():.5f}; '
                                    f'lr: {lr:.5f}'))

            if i % 10 == 0:
                recon_image(n_row, sample_img, model, f'{save_path}', epoch, Tensor)

        save_loss_plots(args.n_epochs, epoch, losses, f'{save_path}')
    if (epoch + 1) % 10 == 0:
        torch.save(model.state_dict(), f'{save_path}/checkpoint/vqvae_{str(epoch + 1).zfill(3)}.pt')
