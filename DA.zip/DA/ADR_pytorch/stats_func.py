import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np

def dice_eval(pred, target, n_cls):
    dice_arr = []
    dice = 0
    eps = 1e-7
    for i in range(n_cls):
        pred_i = pred == i
        target_i = target == i
        dice_i = 2 * (pred_i * target_i).sum() / (pred_i.sum() + target_i.sum() + eps)
        dice_arr.append(dice_i)
        dice += dice_i
    dice /= n_cls
    return dice_arr