import os
import numpy as np
import io
import glob
from PIL import Image
import argparse
import torch
import torch.utils.data
from torch import nn, optim
from torch.nn import functional as F
from torchvision import datasets, transforms
from torchvision.utils import save_image
from torch.utils import tensorboard
import torchvision
import functools
import matplotlib
import collections
from models.VAE import *
from models.VQVAE import *
from models.AE import *
import dataset.brats
matplotlib.use('Agg')

os.environ['CUDA_VISIBLE_DEVICES'] = '2'
np.seterr(all='raise')
np.random.seed(2019)
torch.manual_seed(2019)

parser = argparse.ArgumentParser()

parser.add_argument('--batch-size', type=int, default=512, metavar='N',
                    help='input batch size for training (default: 128)')
parser.add_argument('--epochs', type=int, default=2000, metavar='N',
                    help='number of epochs to train (default: 10)')
parser.add_argument('--save_epoch_interval', type=int, default=5, metavar='N',
                    help='number of epochs to train (default: 10)')
parser.add_argument('--no-cuda', action='store_true', default=False,
                    help='enables CUDA training')
parser.add_argument('--seed', type=int, default=42, metavar='S',
                    help='random seed (default: 1)')
parser.add_argument('--log-interval', type=int, default=1000, metavar='N',
                    help='how many batches to wait before logging training status')
parser.add_argument('--latent-dimension', type=int, default=256, metavar='N',
                    help=' ')
parser.add_argument('--n-channels', type=int, default=1, metavar='N',
                    help=' ')
parser.add_argument('--img-size', type=int, default=256, metavar='N',
                    help=' ')
parser.add_argument('--learning-rate', type=float, default=1e-4, metavar='N',
                    help=' ')
parser.add_argument('--architecture', type=str, default='old', metavar='N',
                    help=' ')
parser.add_argument('--reconstruction-data-loss-weight', type=float, default=1.0,
                    help=' ')
parser.add_argument('--kl-latent-loss-weight', type=float, default=0.01,
                    help=' ')
parser.add_argument("--mri_data_dir", type = str,
                    default ="your_data_path",
                    help = "the data directory")


def record_scalar(writer, scalar_list, scalar_name_list, cur_iter):
    scalar_name_list = scalar_name_list[1:-1].split(',')
    for idx, item in enumerate(scalar_list):
        writer.add_scalar(scalar_name_list[idx].strip(' '), item, cur_iter)


def main(args):
    torch.manual_seed(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    torch.manual_seed(args.seed)

    # model = VAE(cdim=1, hdim=8192, channels=[16,32, 64,128, 256], image_size=256).to(device)
    model = AE().to(device)
    # optimizerE = optim.Adam(model.encoder.parameters(), lr=args.learning_rate)
    # optimizerG = optim.Adam(model.decoder.parameters(), lr=args.learning_rate)
    optimizer = optim.Adam(model.parameters(), lr=1e-3)
    print('Cuda is {}available'.format('' if torch.cuda.is_available() else 'not '))

    from tensorboardX import SummaryWriter
    writer = SummaryWriter(logdir='./runs/VAE')
    t1_list = os.listdir('/home1/jkwang/dataset/BraTS192D/t1')
    t2_list = os.listdir('/home1/jkwang/dataset/BraTS192D/t2')
    mask_list = os.listdir('/home1/jkwang/dataset/BraTS192D/mask')
    all_list = []
    for item in t1_list:
        all_list.append(item)
    for item in t2_list:
        all_list.append(item)

    part = {}
    part = dataset.brats.partitioning(t1_list, split_ratio=[0.8, 0.2, 0])

    dataset_train = dataset.brats.BraTS2Ddataset(part['train'], augment=False)
    dataset_valid = dataset.brats.BraTS2Ddataset(part['valid'], augment=False)

    dataloader_train = torch.utils.data.DataLoader(
        dataset_train,
        batch_size=256,
        num_workers=8,
        pin_memory=True
    )
    dataloader_valid = torch.utils.data.DataLoader(
        dataset_valid,
        batch_size=256,
        num_workers=8,
        pin_memory=True
    )

    cur_iter = 0
    train_res_recon_error = []
    train_res_perplexity = []
    for epoch in range(1, args.epochs + 1):
        model.train()

        for iter, (data, _) in enumerate(dataloader_train):
            data = data.to(device)
            loss_info = '[loss_rec, loss_kl]'

            # real_mu, real_logvar, z, rec = model(data)
            # loss_rec = model.reconstruction_loss(rec, data, True)
            #
            # loss_kl = model.kl_loss(real_mu, real_logvar).mean()
            #
            # loss = loss_rec*256*256 + loss_kl
            #
            pred = model(data)
            # optimizerG.zero_grad()
            # optimizerE.zero_grad()
            recon_error = F.mse_loss(pred, data)
            loss = recon_error
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            # optimizerG.step()
            # optimizerE.step()

            print('Epoch: {} [{}/{} ({:.0f}%)]\tLoss: {:.6f}'.format(
                epoch, iter * len(data), len(dataloader_train.dataset),
                       100. * iter / len(dataloader_train), loss.item()))

        print('====> Epoch: {} Average loss: {:.4f}'.format(
            epoch, loss.item()))
        #     if cur_iter % args.log_interval == 0:
        #         record_scalar(writer, eval(loss_info), loss_info, cur_iter)
        #     print('Train Epoch: {} [{}/{} ({:.0f}%)]\tLoss: {:.6f}'.format(
        #         epoch, iter * len(data), len(dataloader_train.dataset),
        #         100. * iter / len(dataloader_train), loss.item()))
        #     cur_iter += 1
        # print('====> Epoch: {} Average loss: {:.4f}'.format(
        #       epoch, loss.item() / len(data)))
        # if epoch % args.save_epoch_interval == 0:
        #     torch.save(model.state_dict(), './model/VAE_{}.pth'.format(epoch))
        #     print('model saved')




if __name__ == "__main__":
    args = parser.parse_args()
    main(args)