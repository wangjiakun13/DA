import glob
import os
import math
import numpy as np
import torch.nn as nn
import torch.functional as F
from torch.utils.data import DataLoader

os.environ['CUDA_VISIBLE_DEVICES'] = '5'

import torch
from torch import optim
import logger
import argparse
import datetime
import gin
import itertools
import dataset
from torchvision import datasets, transforms
import evaluate

from imageio import imwrite
from torchvision.utils import make_grid
# from
from models.auto_encoder import *
import math
import random
import data.ground_truth.shapes3d as dshapes3d
import data.ground_truth.mpi3d as dmpi3d
import data.ground_truth.dsprites as ddsprit
import data.ground_truth.cars3d as dcars3d

from tensorboardX import SummaryWriter

from models.seg_net import *
from utils.loss import *
from utils.metrics import *

import time

models = {
    'custom': {'vqvae': VQ_CVAE,
               'vqvae2': VQ_CVAE2},
    'imagenet': {'vqvae': VQ_CVAE,
                 'vqvae2': VQ_CVAE2},
    'cifar10': {'vae': CVAE,
                'vqvae': VQ_CVAE,
                'vqvae2': VQ_CVAE2},
    'mnist': {'vae': VAE,
              'vqvae': VQ_CVAE},
    'shapes3d': {
        'vqvae': VQ_CVAE
    },
    'dsprites': {'vae': VAE,
                 'vqvae': VQ_CVAE},
    'mpi_toy': {
        'vqvae': VQ_CVAE
    },
    'mpi_mid': {
        'vqvae': VQ_CVAE
    },
    'mpi_real': {
        'vqvae': VQ_CVAE
    },
    'clevr': {
        'vqvae': VQ_CVAE
    },
    'celebanpz': {
        'vqvae': VQ_CVAE
    },
    'celeba': {
        'vqvae': VQ_CVAE
    },
    'cars3d': {
        'vqvae': VQ_CVAE
    }
}
datasets_classes = {
    'custom': datasets.ImageFolder,
    'imagenet': datasets.ImageFolder,
    'cifar10': datasets.CIFAR10,
    'mnist': datasets.MNIST,
    # 'mnist' : dataset.custum_dataset,
    'shapes3d': dataset.custum_dataset,
    'dsprites': dataset.custum_dataset,
    'mpi_toy': dataset.custum_dataset,
    'mpi_mid': dataset.custum_dataset,
    'mpi_real': dataset.custum_dataset,
    'clevr': dataset.custum_dataset,
    'celebanpz': dataset.custum_dataset,
    'celeba': dataset.custum_dataset,
    'cars3d': dataset.custum_dataset,

}
dataset_train_args = {
    'custom': {},
    'imagenet': {},
    'cifar10': {'train': True, 'download': True},
    'mnist': {'train': True, 'download': True},
    # 'mnist' : {'name':'mnist'},
    'shapes3d': {},
    'dsprites': {'name': 'dsprites'},
    'mpi_toy': {'name': 'mpi_toy'},
    'mpi_mid': {'name': 'mpi_mid'},
    'mpi_real': {'name': 'mpi_real'},
    'clevr': {'name': 'clevr'},
    'celebanpz': {'name': "celebanpz"},
    'celeba': {'name': "celeba"},
    'cars3d': {'name': 'cars3d'}

}
dataset_test_args = {
    'custom': {},
    'imagenet': {},
    'cifar10': {'train': False, 'download': True},
    # 'mnist': {'train': False, 'download': True},
    'mnist': {'name': 'mnist'},
    'shapes3d': {},
    'dsprites': {'name': 'dsprites'},
    'mpi_toy': {'name': 'mpi_toy'},
    'mpi_mid': {'name': 'mpi_mid'},
    'mpi_real': {'name': 'mpi_real'},
    'clevr': {'name': 'clevr'},
    'celebanpz': {'name': "celebanpz"},
    'celeba': {'name': "celeba"},
    'cars3d': {'name': 'cars3d'}
}
dataset_n_channels = {
    'custom': 3,
    'imagenet': 3,
    'cifar10': 3,
    'shapes3d': 3,
    'dsprites': 1,
    'mnist': 1,
    'mpi_toy': 3,
    'mpi_mid': 3,
    'mpi_real': 3,
    'clevr': 3,
    'celebanpz': 3,
    'celeba': 3,
    'cars3d': 3
}
eval_datasets = {
    "shapes3d": dshapes3d.Dataset,
    "mpi_toy": dmpi3d.Dataset,
    "dsprites": ddsprit.Dataset,
    "cars3d": dcars3d.Dataset
}

dataset_transforms = {
    'custom': transforms.Compose([transforms.Resize(256), transforms.CenterCrop(256),
                                  transforms.ToTensor(),
                                  transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))]),
    'imagenet': transforms.Compose([transforms.Resize(256), transforms.CenterCrop(256),
                                    transforms.ToTensor(),
                                    transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))]),
    'cifar10': transforms.Compose([transforms.ToTensor(),
                                   transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))]),
    'shapes3d': transforms.Compose([transforms.ToTensor(),
                                    transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))]),
    'mnist': transforms.Compose([transforms.ToTensor(),
                                 transforms.Normalize((0.5), (0.5))]),
    'dsprites': transforms.Compose([transforms.ToTensor(),
                                    lambda x: 255. * x,
                                    transforms.Normalize((0.5), (0.5))]),
    'mpi_toy': transforms.Compose([transforms.ToTensor(),
                                   transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))]),
    'mpi_mid': transforms.Compose([transforms.ToTensor(),
                                   transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))]),
    'mpi_real': transforms.Compose([transforms.ToTensor(),
                                    transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))]),
    'clevr': transforms.Compose([transforms.Resize(64),
                                 transforms.ToTensor(),
                                 transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))]),
    'celebanpz': transforms.Compose([transforms.Resize(64),
                                     transforms.ToTensor(),
                                     transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))]),
    'celeba': transforms.Compose([transforms.Resize(64),
                                  transforms.ToTensor(),
                                  transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))]),
    'cars3d': transforms.Compose([transforms.Resize(64),
                                  transforms.ToTensor(),
                                  transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))]),
}


def return_shape(tensor, shape):
    return tensor.permute(0, 2, 1).view(-1, *shape[1:])


def gen_image(latents, energy_model, im_neg, flags, selected_idx=False):
    num_steps = flags.num_steps
    create_graph = flags.create_graph
    step_lr = flags.step_lr

    # latents list of Tensors shape (B, 1, D)
    im_negs = []
    im_neg.requires_grad_(requires_grad=True)
    for i in range(num_steps):
        energy = 0
        if selected_idx:
            energy = energy_model[selected_idx](im_neg, latents[0])
        else:
            for j in range(len(latents)):
                energy = energy_model[j % flags.components](im_neg, latents[j]) + energy
        im_grad, = torch.autograd.grad([energy.sum()], [im_neg], create_graph=create_graph)
        im_neg = im_neg - step_lr * im_grad

        im_negs.append(im_neg)
        im_neg = im_neg.detach()
        im_neg.requires_grad_()

    return im_neg, im_negs, im_grad


def decode_image(model, im_code, old_shape):
    pred = im_code
    _, cls_pred = pred.max(dim=-1)
    z_q = model.emb.weight[:, cls_pred].permute(1, 2, 0)
    z_q = return_shape(z_q, old_shape)
    img = model.decode(z_q)
    return img


class Flags():
    def __init__(self):
        pass


@gin.configurable
def get_train_flags(
        resume_iter,
        num_epochs,
        num_steps,
        step_lr,
        log_interval,
        save_interval,
        create_graph=True,
        without_ml=False,
        emb_loss=False,
        **kwargs):
    train_flags = Flags()
    train_flags.resume_iter = resume_iter
    train_flags.num_epochs = num_epochs
    train_flags.num_steps = num_steps
    train_flags.step_lr = step_lr
    train_flags.without_ml = without_ml

    train_flags.create_graph = create_graph
    train_flags.log_interval = log_interval
    train_flags.save_interval = save_interval
    train_flags.emb_loss = emb_loss

    for k, v in kwargs.items():
        train_flags.__setattr__(k, v)
    return train_flags


@gin.configurable
def get_test_flags(
        num_visuals,
        num_steps,
        step_lr,
        num_additional,
        create_graph=False,
        **kwargs
):
    test_flags = Flags()
    test_flags.num_visuals = num_visuals
    test_flags.num_steps = num_steps
    test_flags.step_lr = step_lr
    test_flags.num_additional = num_additional
    test_flags.create_graph = create_graph
    for k, v in kwargs.items():
        test_flags.__setattr__(k, v)

    return test_flags


@gin.configurable
def get_args(
        dataset_dir_name="",
        image_energy=False,
        joint_train=False,
        load_path=False,
        **kwargs
):
    args = Flags()
    for k, v in kwargs.items():
        args.__setattr__(k, v)
    args.dataset_dir_name = dataset_dir_name
    args.image_energy = image_energy
    args.joint_train = joint_train
    args.load_path = load_path
    return args


@gin.configurable
def get_model_args(
        model,
        hidden,
        k,
        num_channels,
        lr,
        lr_sche,
        **kwargs
):
    model_args = Flags()
    model_args.model = model
    model_args.hidden = hidden
    model_args.k = k
    model_args.num_channels = num_channels
    model_args.lr = lr
    model_args.lr_sche = lr_sche
    for k, v in kwargs.items():
        model_args.__setattr__(k, v)
    return model_args


def softmax_entropy(x: torch.Tensor) -> torch.Tensor:
    """Entropy of softmax distribution from logits."""
    return -(x.softmax(1) * x.log_softmax(1)).sum(1)


def train(train_loader, seg, model1, model2, decoder_model, latent_encoder, criterion, optimizer, seg_optimizer, eval_dataset, test_loader):
    train_flags = get_train_flags()
    train_flags.components = latent_encoder.components
    it = train_flags.resume_iter
    logdir = os.path.join(logger.get_dir(), "checkpoints")
    ce_loss = nn.CrossEntropyLoss()
    os.makedirs(os.path.expanduser(logdir), exist_ok=True)
    training_res = []
    val_res = []
    for epoch in range(train_flags.num_epochs):
        st = time.time()
        train_class_dices = np.array([0] * (3), dtype=np.float)
        val_class_dices = np.array([0] * (3), dtype=np.float)
        val_dice_arr = []
        train_losses = []
        val_losses = []
        seg.train()
        for batch_idx, (data, mask) in enumerate(train_loader):
            t1, t2 = data
            # mask = np.array(mask)
            bs = t1.shape[0]
            sample_mat = np.array([[i for i in range(bs) if i != j] for j in range(bs)])
            indexes = np.array([i for i in range(bs)])
            t1 = t1.cuda()
            t2 = t2.cuda()
            mask = mask.cuda()
            optimizer.zero_grad()
            with torch.no_grad():
                im_code_t1 = model1.encode(t1)
                im_code_t2 = model2.encode(t2)
                old_shape = im_code_t1.shape
            im_emb_t1, labels_t1 = model1.emb(im_code_t1.detach())
            im_emb_t2, labels_t2 = model2.emb(im_code_t2.detach())
            im_code_new_t1 = im_emb_t1.view(im_code_t1.shape[0], im_code_t1.shape[1], -1).permute(0, 2, 1)
            im_code_new_t2 = im_emb_t2.view(im_code_t2.shape[0], im_code_t2.shape[1], -1).permute(0, 2, 1)


            im_code_new_t1 = im_code_new_t1.view(im_code_new_t1.shape[0], 40, 40, -1).permute(0, 3, 1, 2)
            out = seg(im_code_new_t1)

            seg_optimizer.zero_grad()
            loss = criterion(out, mask)
            loss.backward()
            seg_optimizer.step()
            train_losses.append(loss.item())

            class_dice = []
            for i in range(1, 4):
                cur_dice = diceCoeffv2(out[:, i:i + 1, :], mask[:, i:i + 1, :]).cpu().item()
                class_dice.append(cur_dice)

            mean_dice = sum(class_dice) / len(class_dice)
            train_class_dices += np.array(class_dice)
            string_print = 'epoch: {} - iters: {} - loss: {:.4} - mean: {:.4} - et: {:.4}- tc: {:.4} - wt: {:.4} - time: {:.2}' \
                .format(epoch, batch_idx, loss.data.cpu(), mean_dice, class_dice[0], class_dice[1], class_dice[2],
                        time.time() - st)
            log(string_print)
            st = time.time()

        train_loss = np.average(train_losses)
        train_class_dices = train_class_dices / batch_idx
        train_mean_dice = train_class_dices.sum() / train_class_dices.size

        writer.add_scalar('train main_loss', train_loss, epoch)
        writer.add_scalar('train main_dice', train_mean_dice, epoch)

        print(
            'epoch {}/{} - train_loss: {:.4} - train_mean_dice: {:.4} - dice_et: {:.4} - dice_tc: {:.4} - dice_wt: {:.4}'.format(
                epoch, train_flags.num_epochs, train_loss, train_mean_dice, train_class_dices[0], train_class_dices[1],
                train_class_dices[2]))

        seg.eval()
        with torch.no_grad():
            for val_batch_idx, (data, mask) in enumerate(test_loader):
                t1, t2 = data
                bs = t1.shape[0]
                sample_mat = np.array([[i for i in range(bs) if i != j] for j in range(bs)])
                indexes = np.array([i for i in range(bs)])
                t1 = t1.cuda()
                t2 = t2.cuda()
                mask = mask.cuda()
                im_code_t1 = model1.encode(t1)
                im_code_t2 = model2.encode(t2)
                old_shape = im_code_t1.shape
                im_emb_t1, labels_t1 = model1.emb(im_code_t1.detach())
                im_emb_t2, labels_t2 = model2.emb(im_code_t2.detach())
                im_code_new_t1 = im_emb_t1.view(im_code_t1.shape[0], im_code_t1.shape[1], -1).permute(0, 2, 1)
                im_code_new_t2 = im_emb_t2.view(im_code_t2.shape[0], im_code_t2.shape[1], -1).permute(0, 2, 1)

                my_latents_t1 = latent_encoder(im_code_new_t1)
                my_latents_t2 = latent_encoder(im_code_new_t2)

                my_latents_t1 = my_latents_t1.view(my_latents_t1.shape[0], 40, 40, -1).permute(0, 3, 1, 2)
                pred = seg(my_latents_t1)

                val_loss = criterion(pred, mask)
                val_losses.append(val_loss.item())

                pred = pred.detach()

                val_class_dice = []
                for i in range(1, 4):
                    val_class_dice.append(diceCoeffv2(pred[:, i:i + 1, :], mask[:, i:i + 1, :]).cpu())

                val_dice_arr.append(val_class_dice)
                val_class_dices += np.array(val_class_dice)

            val_loss = np.average(val_losses)

            val_dice_arr = np.array(val_dice_arr)
            std = (np.std(val_dice_arr[:, 1:2]) + np.std(val_dice_arr[:, 2:3]) + np.std(
                val_dice_arr[:, 3:4])) / 4
            val_class_dices = val_class_dices / val_batch_idx

            val_mean_dice = val_class_dices.sum() / val_class_dices.size
            organ_mean_dice = (val_class_dices[0] + val_class_dices[1] + val_class_dices[2]) / 4

            writer.add_scalar('lr', optimizer.param_groups[0]['lr'], epoch)
            writer.add_scalar('val main_loss', val_loss, epoch)
            writer.add_scalar('val main_dice', val_mean_dice, epoch)
            writer.add_scalar('val lesion_dice', organ_mean_dice, epoch)

            print('val_loss: {:.4} - val_mean_dice: {:.4} - mean: {:.4}±{:.3} - et: {:.4}- tc: {:.4} - wt: {:.4}'
                  .format(val_loss, val_mean_dice, organ_mean_dice, std, val_class_dices[0], val_class_dices[1],
                          val_class_dices[2]))
            print('lr: {}'.format(optimizer.param_groups[0]['lr']))

        print('epoch {} took {:.2} seconds'.format(epoch, time.time() - st))
        print('..................................................')




def log(X, f=None):
    time_stamp = datetime.datetime.now().strftime("[%Y-%m-%d %H:%M:%S]")
    if not f:
        # print(time_stamp + " " + X)
        print(X)
    else:
        f.write(time_stamp + " " + X)

def random_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True

def make_loader(data_dir, batch_size):
    patient_list = {}
    base_dir = '/home1/jkwang/dataset/BraTS192D/img'
    # patient_list['t1'] = []
    # patient_list['t2'] = []
    # patient_list['mask'] = []
    patient_path_list = {}
    patient_path_list['T1'] = {}
    patient_path_list['T2'] = {}
    patient_path_list['Masks'] = {}
    patient_image_cnt_T1 = {}
    patient_image_cnt_T2 = {}
    patient_image_cnt_Mask = {}
    for dir in os.listdir(base_dir):
        patient_path_list['T1'][dir] = sorted(glob.glob(os.path.join(base_dir, dir, 't1', '*.png')))
        patient_image_cnt_T1[dir] = len(patient_path_list['T1'][dir])
        patient_path_list['T2'][dir] = sorted(glob.glob(os.path.join(base_dir, dir, 't2', '*.png')))
        patient_image_cnt_T2[dir] = len(patient_path_list['T2'][dir])
        patient_path_list['Masks'][dir] = sorted(glob.glob(os.path.join(base_dir, dir, 'mask', '*.png')))
        patient_image_cnt_Mask[dir] = len(patient_path_list['Masks'][dir])

    keys_to_delete = [k for k in patient_image_cnt_T1 if
                      patient_image_cnt_T1[k] != patient_image_cnt_Mask[k] or patient_image_cnt_T1[k] == 0
                      or patient_image_cnt_Mask[k] == 0]
    for k in keys_to_delete:
        del patient_image_cnt_T1[k], patient_image_cnt_Mask[k], patient_path_list['T1'][k], \
            patient_path_list['Masks'][k], patient_image_cnt_T2[k], patient_path_list['T2'][k]
    import data_loader
    part = data_loader.partitioning([*patient_image_cnt_T1.keys()], split_ratio=[0.7, 0.2, 0.1])
    partition_train = {}
    partition_train['T1'] = []
    partition_train['T2'] = []
    partition_train['Masks'] = []
    for p in part['train']:
        partition_train['T1'].extend(patient_path_list['T1'][p])
        partition_train['T2'].extend(patient_path_list['T2'][p])
        partition_train['Masks'].extend(patient_path_list['Masks'][p])
    partition_val = {}
    partition_val['T1'] = []
    partition_val['T2'] = []
    partition_val['Masks'] = []
    for p in part['valid']:
        partition_val['T1'].extend(patient_path_list['T1'][p])
        partition_val['T2'].extend(patient_path_list['T2'][p])
        partition_val['Masks'].extend(patient_path_list['Masks'][p])
    partition_test = {}
    partition_test['T1'] = []
    partition_test['T2'] = []
    partition_test['Masks'] = []
    for p in part['test']:
        partition_test['T1'].extend(patient_path_list['T1'][p])
        partition_test['T2'].extend(patient_path_list['T2'][p])
        partition_test['Masks'].extend(patient_path_list['Masks'][p])

    train_dataset = data_loader.BraTS_2D_all_dataset(partition_train, augment=False)
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=1)
    val_dataset = data_loader.BraTS_2D_all_dataset(partition_val, augment=False)
    val_loader =  DataLoader(val_dataset, batch_size=batch_size, shuffle=False, num_workers=1)
    test_dataset = data_loader.BraTS_2D_all_dataset(partition_test, augment=False)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False, num_workers=1)
    return train_loader, val_loader, test_loader


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="training codes")
    parser.add_argument("--debug", type=bool, default=False,
                        help="debug mode or not")
    parser.add_argument("--config", type=str, default="configs/brats_t1_ce.gin",
                        help="config file path")
    parser.add_argument("--enc_model", type=str, default="sc_decoder",
                        help="config file path")
    parser.add_argument("--wo_dis_loss", type=bool, default=True,
                        help="config settings")
    parser.add_argument("--batch_size", type=int, default=-1,
                        help="config settings")
    parser.add_argument("--concepts_num", type=int, default=20,
                        help="config settings")
    parser.add_argument("--seed", type=int, default=-1,
                        help="config settings")
    meta_args = parser.parse_args()
    time_exp = datetime.datetime.now().strftime("exp" + (f"_cn{meta_args.concepts_num}_") + (
        f"_b{meta_args.batch_size}_" if not meta_args.batch_size == -1 else "") + (
                                                "wo_dis_" if meta_args.wo_dis_loss else "") + meta_args.enc_model + "-%Y-%m-%d-%H-%M-%S-%f")
    if meta_args.enc_model == "sc_decoder":
        from models.vct_brats import VCT_Decoder, VCT_Encoder
    else:
        assert NotImplemented
    gin.parse_config_file(meta_args.config)
    if meta_args.seed == -1:
        seed = np.random.randint(1e6)
    else:
        seed = meta_args.seed
    random_seed(51)
    args = get_args()
    gin.constant('num_steps', args.num_steps)
    gin.constant('step_lr', args.step_lr)
    gin.constant('image_energy', args.image_energy)
    gin.parse_config_file(f"configs/{args.name}_shared.gin")

    if not meta_args.wo_dis_loss:
        gin.bind_parameter("get_train_flags.dis_loss", True)
    else:
        gin.bind_parameter("get_train_flags.dis_loss", False)

    logger.configure(out_dir="%s_vqvae_deeplabv3" % args.name, debug=meta_args.debug, time=time_exp)
    logger.log(f"seed:{seed}")
    logger.log(meta_args.config)

    writer = SummaryWriter(log_dir="%s_vqvae_deeplabv3" % args.name + "/" + 'tensorboard' + "/" + time_exp)
    model_args = get_model_args()
    model1 = VQ_CVAE(model_args.hidden, k=model_args.k, num_channels=model_args.num_channels)
    model1.cuda()
    # load
    model1.load_state_dict(torch.load(model_args.path, map_location='cpu'))

    model2 = VQ_CVAE(model_args.hidden, k=model_args.k, num_channels=model_args.num_channels)
    model2.cuda()
    # load
    model2.load_state_dict(torch.load('/home1/jkwang/code/da/VCT/results_t2/2022-11-22_05-21-03/checkpoints/model_200.pth', map_location='cpu'))

    vct_enc = VCT_Encoder(z_index_dim=1600)
    vct_dec = VCT_Decoder(index_num=model_args.k, z_index_dim=model_args.shape_num, ce_loss=True)

    vct_enc.cuda()
    vct_dec.cuda()

    seg = DeepLabHeadV3Plus(in_channels=256, low_level_channels=256, num_classes=4)
    seg.cuda()

    model1.joint_train = args.joint_train
    model1.eval()

    model2.joint_train = args.joint_train
    model2.eval()
    for p in model1.parameters():
        p.requires_grad_(False)
    optimizer = optim.Adam(itertools.chain(vct_enc.parameters(), vct_dec.parameters()), lr=model_args.lr)
    seg_optimizer = optim.Adam(seg.parameters(), lr=1e-4, weight_decay=1e-5)
    for p in model2.parameters():
        p.requires_grad_(False)

    if args.load_path:
        vct_enc.load_state_dict(torch.load(args.load_path)['encoder_model_state_dict'])
        vct_dec.load_state_dict(torch.load(args.load_path)['decoder_model_state_dict'])

    train_dir = '/home1/jkwang/dataset/BraTS192D/img'
    criterion = SoftDiceLoss(4).cuda()
    train_loader, val_loader, test_loader = make_loader(data_dir=train_dir, batch_size=32)


    train(train_loader, seg, model1, model2, vct_dec, vct_enc, criterion, optimizer, seg_optimizer, val_loader, test_loader)