import math
import sys
from typing import Iterable

import torch
import torch.nn as nn

import utils

def train_one_epoch(model: torch.nn.Module,
                    dataloader_train: Iterable, dataloader_valid: Iterable,
                    optimizer: torch.optim.Optimizer,
                    device: torch.device, epoch: int, loss_scaler,
                    max_norm: float = 0, log_writer=None,
                    lr_scheduler=None, start_steps=None,
                    lr_schedule_values=None, wd_schedule_values=None):
    model.train()
    # metric_logger = utils.MetricLogger(delimiter="  ")
    # metric_logger.add_meter('lr', utils.SmoothedValue(window_size=1, fmt='{value:.6f}'))
    # metric_logger.add_meter('min_lr', utils.SmoothedValue(window_size=1, fmt='{value:.6f}'))
    print_freq = 10
    header = 'Epoch: [{}]'.format(epoch)

    train_loss = 0.0
    valid_loss = 0.0
    show_every = 50

    print('Training...')

    for step, (image, _) in enumerate(dataloader_train):
        it = start_steps + step
        image = image.to(device)

        loss = model(image)
        loss_value = loss.item()
        if not math.isfinite(loss_value):
            print("Loss is {}, stopping training".format(loss_value))
            sys.exit(1)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        train_loss += ((1 / (step + 1)) * (loss_value - train_loss))

    print('validating...')

    model.eval()
    with torch.no_grad():
        for step, (image, _) in enumerate(dataloader_valid):
            output = model(image.to(device))
            valid_loss += ((1 / (step + 1)) * (output.item() - valid_loss))

    return train_loss, valid_loss

