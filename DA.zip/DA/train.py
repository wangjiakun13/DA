import os
import random
import datetime
import argparse
import numpy as np

from utils import Parser

import torch
import torchvision.transforms as tfs
from torch import optim
from torch.optim import Adam
from torch.backends import cudnn
from torch.nn import DataParallel
from torch.utils.data import DataLoader
from ADR_pytorch.model import GeneratorResnet, DiscriminatorB, ContentEncoder,Discriminator, BuildSpfCls, Outputs

if __name__ == '__main__':
    x = torch.rand([8, 256, 256, 1])
    x = x.permute(0, 3, 1, 2)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    x = x.to(device)
    x = x.cuda()
    y = torch.rand([8, 256, 256, 1]).permute(0, 3, 1, 2)
    y = y.to(device)
    y = y.cuda()
    inputs = {'images_a': x, 'images_b': y}
    obj={key:inputs[key].cuda() for key in inputs}
    model = GeneratorResnet()
    model1 = DiscriminatorB()
    model2 = ContentEncoder()
    model3 = Discriminator()
    model4 = BuildSpfCls()
    z = torch.rand([8, 256, 32, 32])
    z = z.to(device)
    z = z.cuda()
    model.cuda()
    model1.cuda()
    model2.cuda()
    model3.cuda()
    model4.cuda()
    model5 = Outputs()
    model5.cuda()

    out = model5(inputs)



    
