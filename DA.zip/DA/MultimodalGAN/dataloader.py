import torch
import torch.utils.data
from torch.utils.data import Dataset
import albumentations as A
import torchio as tio
import random
from random import shuffle
from PIL import Image
import torch.nn.functional as F
import numpy as np
import os

from torchvision import transforms


def partitioning(patients_list, split_ratio):
    part = {'train': [], 'valid': [], 'test': []}
    random.shuffle(patients_list)
    l = len(patients_list)
    split_pt = [int(split_ratio[0] * l), int((split_ratio[0] + split_ratio[1]) * l)]
    part['train'] = patients_list[:split_pt[0]]
    part['valid'] = patients_list[split_pt[0]:split_pt[1]]
    part['test'] = patients_list[split_pt[1]:]
    print('train: ', len(part['train']), ' ', 'valid: ', len(part['valid']), ' ', 'test: ', len(part['test']))
    return part

class MM_2D_dataset_source(Dataset):
    def __init__(self, partition, augment=False):
        self.partition = partition
        self.augment = augment


    def __len__(self):
        return (len(self.partition['CT']))

    def __getitem__(self, idx):
        image = np.load(self.partition['CT'][idx]).astype(np.float32)
        mask = np.load(self.partition['Masks'][idx]).astype(np.float32)
        t1 = transforms.ToTensor()

        if self.augment:
            image = self.augment(image)
            mask = self.augment(mask)
        else:
            image = t1(image)
            mask = torch.as_tensor(mask)

        mask = torch.unsqueeze(mask, 0)
        #resize
        image = transforms.Resize((256, 256))(image)
        mask = transforms.Resize((256, 256))(mask)
        image = image.type(torch.FloatTensor)
        mask = mask.type(torch.FloatTensor)
        image_a = image
        iamge_b = image

        return image_a, iamge_b, mask

class MM_2D_dataset_target(Dataset):
    def __init__(self, partition, augment=False):
        self.partition = partition
        self.augment = augment


    def __len__(self):
        return (len(self.partition['MR']))

    def __getitem__(self, idx):
        image = np.load(self.partition['MR'][idx]).astype(np.float32)
        mask = np.load(self.partition['Masks'][idx]).astype(np.float32)
        t1 = transforms.ToTensor()

        if self.augment:
            image = self.augment(image)
            mask = self.augment(mask)
        else:
            image = t1(image)
            mask = torch.as_tensor(mask)

        mask = torch.unsqueeze(mask, 0)
        image = transforms.Resize((256, 256))(image)
        mask = transforms.Resize((256, 256))(mask)
        image = image.type(torch.FloatTensor)
        mask = mask.type(torch.FloatTensor)



        return image

class MM_2D_dataset_all(Dataset):
    def __init__(self, partition_s, partition_t, augment=False):
        self.partition_s = partition_s
        self.partition_t = partition_t
        self.augment = augment


    def __len__(self):
        return (len(self.partition_s['CT']) + len(self.partition_t['MR']))

    def __getitem__(self, idx):
        image_s = np.load(self.partition_s['CT'][idx]).astype(np.float32)
        image_t = np.load(self.partition_t['MR'][idx]).astype(np.float32)
        mask = None
        t1 = transforms.ToTensor()

        if self.augment:
            image_s = self.augment(image_s)
            image_t = self.augment(image_t)
            mask = self.augment(mask)
        else:
            image_s = t1(image_s)
            image_t = t1(image_t)



        image_s = transforms.Resize((256, 256))(image_s)
        image_t = transforms.Resize((256, 256))(image_t)

        image_s = image_s.type(torch.FloatTensor)
        image_t = image_t.type(torch.FloatTensor)




        return image_s, image_t, mask