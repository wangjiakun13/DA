import numpy
import torch
import torch.nn as nn
import torch.nn.functional as F

class ResidualBlock(nn.Module):
    def __init__(self, in_channels, out_channels, stride=1, downsample=None):
        super(ResidualBlock, self).__init__()
        self.conv1 = nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(out_channels)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = nn.Conv2d(out_channels, out_channels, kernel_size=3, stride=1, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(out_channels)
        self.downsample = downsample

    def forward(self, x):
        residual = x
        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)
        out = self.conv2(out)
        out = self.bn2(out)
        if self.downsample:
            residual = self.downsample(x)
        out += residual
        out = self.relu(out)
        return out


class GeneratorResnet(nn.Module):
    def __init__(self, in_channels=1, out_channels=1, num_residual_blocks=9, skip=False):
        super(GeneratorResnet, self).__init__()
        self.o_c1 = nn.Conv2d(in_channels, 32, kernel_size=7, stride=1)
        self.o_c1_in = nn.InstanceNorm2d(32)
        self.o_c1_relu = nn.ReLU(inplace=True)

        self.o_c2 = nn.Conv2d(32, 64, kernel_size=3, stride=2, padding=1)
        self.o_c2_in = nn.InstanceNorm2d(64)
        self.o_c2_relu = nn.ReLU(inplace=True)

        self.o_c3 = nn.Conv2d(64, 128, kernel_size=3, stride=2, padding=1)
        self.o_c3_in = nn.InstanceNorm2d(128)
        self.o_c3_relu = nn.ReLU(inplace=True)

        self.residual_blocks = []
        for _ in range(num_residual_blocks):
            self.residual_blocks.append(ResidualBlock(128, 128, 1, None))
        self.residual_blocks = nn.Sequential(*self.residual_blocks)

        self.o_c4 = nn.ConvTranspose2d(128, 64, kernel_size=3, stride=2, padding=1, output_padding=1)
        self.o_c4_in = nn.InstanceNorm2d(64)
        self.o_c4_relu = nn.ReLU(inplace=True)
        self.o_c5 = nn.ConvTranspose2d(64, 32, kernel_size=3, stride=2, padding=1, output_padding=1)
        self.o_c5_in = nn.InstanceNorm2d(32)
        self.o_c5_relu = nn.ReLU(inplace=True)
        self.o_c6 = nn.Conv2d(32, out_channels, kernel_size=7, stride=1, padding=3)
        self.skip = skip


    def forward(self, x):
        out = torch.nn.functional.pad(x, (3, 3, 3, 3, 0, 0))
        out = self.o_c1(out)
        out = self.o_c1_in(out)
        out = self.o_c1_relu(out)
        out = self.o_c2(out)
        out = self.o_c2_in(out)
        out = self.o_c2_relu(out)
        out = self.o_c3(out)
        out = self.o_c3_in(out)
        out = self.o_c3_relu(out)
        out = self.residual_blocks(out)
        out = self.o_c4(out)
        out = self.o_c4_in(out)
        out = self.o_c4_relu(out)
        out = self.o_c5(out)
        out = self.o_c5_in(out)
        out = self.o_c5_relu(out)
        out = self.o_c6(out)
        if self.skip:
            out = out + x
            out = F.tanh(out)
        else:
            out = F.tanh(out)
        return out


class DiscriminatorB(nn.Module):
    def __init__(self):
        super(DiscriminatorB, self).__init__()
        self.f = 3
        self.o_c1 = nn.Conv2d(1, 64, kernel_size=4, stride=2)
        self.o_c1_lrelu = nn.LeakyReLU(0.02, inplace=True)
        self.o_c2 = nn.Conv2d(64, 128, kernel_size=4, stride=2)
        self.o_c2_in = nn.InstanceNorm2d(128)
        self.o_c2_lrelu = nn.LeakyReLU(0.02, inplace=True)
        self.o_c3 = nn.Conv2d(128, 256, kernel_size=4, stride=2)
        self.o_c3_in = nn.InstanceNorm2d(256)
        self.o_c3_lrelu = nn.LeakyReLU(0.02, inplace=True)
        self.o_c4 = nn.Conv2d(256, 512, kernel_size=4, stride=1)
        self.o_c4_in = nn.InstanceNorm2d(512)
        self.o_c4_lrelu = nn.LeakyReLU(0.02, inplace=True)
        self.o_c5 = nn.Conv2d(512, 1, kernel_size=4, stride=1)


    def forward(self, x):
        out = torch.nn.functional.pad(x, (2, 2, 2, 2, 0, 0))
        out = self.o_c1(out)
        out = self.o_c1_lrelu(out)
        out = torch.nn.functional.pad(out, (2, 2, 2, 2, 0, 0))
        out = self.o_c2(out)
        out = self.o_c2_in(out)
        out = self.o_c2_lrelu(out)
        out = torch.nn.functional.pad(out, (2, 2, 2, 2, 0, 0))
        out = self.o_c3(out)
        out = self.o_c3_in(out)
        out = self.o_c3_lrelu(out)
        out = torch.nn.functional.pad(out, (2, 2, 2, 2, 0, 0))
        out = self.o_c4(out)
        out = self.o_c4_in(out)
        out = self.o_c4_lrelu(out)
        out = torch.nn.functional.pad(out, (2, 2, 2, 2, 0, 0))
        out = self.o_c5(out)

        return out

class Drn(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(Drn, self).__init__()
        self.conv1 = nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=1, padding=0, dilation=2)
        self.conv2 = nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=1, padding=0, dilation=2)
        self.dropout = nn.Dropout2d()
        self.relu = nn.ReLU(inplace=True)
        self.norm = nn.BatchNorm2d(out_channels)

    def forward(self, x):
        out = nn.functional.pad(x, (2, 2, 2, 2, 0, 0))
        out = self.conv1(out)
        out = self.dropout(out)
        out = self.norm(out)
        out = self.relu(out)
        out = nn.functional.pad(out, (2, 2, 2, 2, 0, 0))
        out = self.conv2(out)
        out = self.dropout(out)
        out = self.norm(out)
        out = self.relu(out)

        out = out + x

        out = self.relu(out)

        return out

class ContentEncoder(nn.Module):
    def __init__(self):
        super(ContentEncoder, self).__init__()
        self.o_c1 = nn.Conv2d(1, 16, kernel_size=7, stride=1, padding=3)
        self.o_c1_bn = nn.BatchNorm2d(16)
        self.o_c1_relu = nn.ReLU(inplace=True)
        self.o_r1 = ResidualBlock(16, 16)
        self.ou1 = nn.MaxPool2d(kernel_size=2, stride=2)

        self.o_c2 = nn.Conv2d(16, 32, kernel_size=7, stride=1, padding=3)
        self.o_r2 = ResidualBlock(32, 32)
        self.ou2 = nn.MaxPool2d(kernel_size=2, stride=2)

        self.o_c3 = nn.Conv2d(32, 64, kernel_size=7, stride=1, padding=3)
        self.o_r3 = ResidualBlock(64, 64)
        self.o_r4 = ResidualBlock(64, 64)
        self.ou3 = nn.MaxPool2d(kernel_size=2, stride=2)

        self.o_c4 = nn.Conv2d(64, 128, kernel_size=7, stride=1, padding=3)
        self.o_r5 = ResidualBlock(128, 128)
        self.o_r6 = ResidualBlock(128, 128)

        self.o_c5 = nn.Conv2d(128, 256, kernel_size=7, stride=1, padding=3)
        self.o_r7 = ResidualBlock(256, 256)
        self.o_r8 = ResidualBlock(256, 256)

        self.o_r9 = ResidualBlock(256, 256)
        self.o_r10 = ResidualBlock(256, 256)

        self.o_c6 = nn.Conv2d(256, 512, kernel_size=7, stride=1, padding=3)
        self.o_r11 = ResidualBlock(512, 512)
        self.o_r12 = ResidualBlock(512, 512)

        # self.o_r12_1 = nn.ConvTranspose2d(512, 512, kernel_size=3, stride=2, padding=1, dilation=2)

        self.o_c7 = nn.Conv2d(512, 512, kernel_size=7, stride=1, padding=3)
        self.o_c7_bn = nn.BatchNorm2d(512)
        self.o_c7_relu = nn.ReLU(inplace=True)

        self.o_c8 = nn.Conv2d(512, 512, kernel_size=7, stride=1, padding=3)
        self.o_c8_bn = nn.BatchNorm2d(512)
        self.o_c8_relu = nn.ReLU(inplace=True)

        self.drn_1 = nn.Conv2d(512, 512, kernel_size=3, stride=1, dilation=2, padding=0)
        self.drn_1_dropout = nn.Dropout2d()
        self.drn_1_relu = nn.ReLU(inplace=True)
        self.drn_1 = Drn(512, 512)
        self.drn_2 = Drn(512, 512)

        self.o_c9 = nn.Conv2d(512, 512, kernel_size=3, stride=1, padding=1)
        self.o_c9_bn = nn.BatchNorm2d(512)
        self.o_c9_relu = nn.ReLU(inplace=True)

        self.o_c10 = nn.Conv2d(512, 512, kernel_size=3, stride=1, padding=1)
        self.o_c10_bn = nn.BatchNorm2d(512)
        self.o_c10_relu = nn.ReLU(inplace=True)


    def forward(self, x):
        out = self.o_c1(x)
        out = self.o_c1_bn(out)
        out = self.o_c1_relu(out)
        out = self.o_r1(out)
        out = self.ou1(out)

        out = self.o_c2(out)
        out = self.o_r2(out)
        out = self.ou2(out)
        out = self.o_c3(out)
        out = self.o_r3(out)
        out = self.o_r4(out)
        out = self.ou3(out)
        out = self.o_c4(out)
        out = self.o_r5(out)
        out = self.o_r6(out)
        out = self.o_c5(out)
        out = self.o_r7(out)
        out = self.o_r8(out)
        out = self.o_r9(out)
        out = self.o_r10(out)
        out = self.o_c6(out)
        out = self.o_r11(out)
        out = self.o_r12(out)

        out1 = out

        # out = torch.nn.functional.pad(out, (2, 2, 2, 2, 0, 0))

        out = self.o_c7(out)
        out = self.o_c7_bn(out)
        out = self.o_c7_relu(out)
        out = self.o_c8(out)
        out = self.o_c8_bn(out)
        out = self.o_c8_relu(out)

        out = self.drn_1(out)
        out = self.drn_2(out)

        out = self.o_c9(out)
        out = self.o_c9_bn(out)
        out = self.o_c9_relu(out)

        out = self.o_c10(out)
        out = self.o_c10_bn(out)
        out = self.o_c10_relu(out)

        z_inv = out[:, 0:256, :, :]
        z_spf = out[:, 256:512, :, :]

        logist_inv = F.avg_pool2d(z_inv, kernel_size=32, stride=8)
        logist_spf = F.avg_pool2d(z_spf, kernel_size=32, stride=8)

        z_inv_aux = out1[:, 0:256, :, :]
        z_spf_aux = out1[:, 256:512, :, :]
        logist_inv_aux = F.avg_pool2d(z_inv_aux, kernel_size=32, stride=8)
        logist_spf_aux = F.avg_pool2d(z_spf_aux, kernel_size=32, stride=8)

        z_inv_1 = numpy.max(z_inv.cpu().data.numpy(), axis=1, keepdims=True)
        #numpy to tensor
        z_inv_1 = torch.from_numpy(z_inv_1).float().cuda()
        Attn = F.upsample(z_inv_1, size=(256, 256), mode='bilinear')
        Attn = (Attn - torch.min(Attn)) / (torch.max(Attn) - torch.min(Attn))

        z_inv_aux_1 = numpy.max(z_inv_aux.cpu().data.numpy(), axis=1, keepdims=True)
        #numpy to tensor
        z_inv_aux_1 = torch.from_numpy(z_inv_aux_1).float().cuda()
        Attn_aux = F.upsample(z_inv_aux_1, size=(256, 256), mode='bilinear')

        Attn_aux = (Attn_aux - torch.min(Attn_aux)) / (torch.max(Attn_aux) - torch.min(Attn_aux))

        return z_inv, z_spf, logist_inv.view(-1, 256), logist_spf.view(-1, 256), z_inv_aux, z_spf_aux, logist_inv_aux.view(-1, 256), logist_spf_aux.view(-1, 256), Attn, Attn_aux


class Segmentor(nn.Module):
    def __init__(self):
        super(Segmentor, self).__init__()
        self.o_c8 = nn.Conv2d(256, 5, kernel_size=1, stride=1, padding=1)
        self.o_c8_dropout = nn.Dropout2d(p=0.75)
        self.upsample = nn.Upsample(size=(256, 256), mode='bilinear')

    def forward(self, x):
        out = self.o_c8(x)
        out = self.o_c8_dropout(out)
        out = self.upsample(out)
        return out

class Discriminator(nn.Module):
    def __init__(self):
        super(Discriminator, self).__init__()
        self.o_c1 = nn.Conv2d(5, 64, kernel_size=4, stride=2)
        self.o_c1_bn = nn.BatchNorm2d(64)
        self.o_c1_relu = nn.LeakyReLU(0.2, inplace=True)

        self.o_c2 = nn.Conv2d(64, 128, kernel_size=4, stride=2)
        self.o_c2_bn = nn.BatchNorm2d(128)
        self.o_c2_relu = nn.LeakyReLU(0.2, inplace=True)

        self.o_c3 = nn.Conv2d(128, 256, kernel_size=4, stride=2)
        self.o_c3_bn = nn.BatchNorm2d(256)
        self.o_c3_relu = nn.LeakyReLU(0.2, inplace=True)

        self.o_c4 = nn.Conv2d(256, 512, kernel_size=4, stride=1)
        self.o_c4_bn = nn.BatchNorm2d(512)
        self.o_c4_relu = nn.LeakyReLU(0.2, inplace=True)

        self.o_c5 = nn.Conv2d(512, 1, kernel_size=4, stride=1)

    def forward(self, x):
        out = F.pad(x, (2, 2, 2, 2, 0, 0))
        out = self.o_c1(out)
        out = self.o_c1_bn(out)
        out = self.o_c1_relu(out)

        out = F.pad(out, (2, 2, 2, 2, 0, 0))
        out = self.o_c2(out)
        out = self.o_c2_bn(out)
        out = self.o_c2_relu(out)

        out = F.pad(out, (2, 2, 2, 2, 0, 0))
        out = self.o_c3(out)
        out = self.o_c3_bn(out)
        out = self.o_c3_relu(out)

        out = F.pad(out, (2, 2, 2, 2, 0, 0))
        out = self.o_c4(out)
        out = self.o_c4_bn(out)
        out = self.o_c4_relu(out)

        out = F.pad(out, (2, 2, 2, 2, 0, 0))
        out = self.o_c5(out)

        return out


class BuildSpfCls(nn.Module):
    def __init__(self):
        super(BuildSpfCls, self).__init__()

        self.conv = nn.Conv2d(256, 512, 3, 2)
        self.conv_bn = nn.BatchNorm2d(512)
        self.conv_relu = nn.ReLU(inplace=True)

        self.linear_1 = nn.Linear(512, 128)
        self.linear_relu = nn.ReLU(inplace=True)

        self.linear_2 = nn.Linear(128, 2)


    def forward(self, x):
        out = F.pad(x, (1, 1, 1, 1, 0, 0))
        out = self.conv(out)
        out = self.conv_bn(out)
        out = self.conv_relu(out)

        out = F.avg_pool2d(out, kernel_size=16, stride=4)
        out = out.view(out.size(0), -1)

        out = self.linear_1(out)
        out = self.linear_relu(out)
        out = self.linear_2(out)

        return out

class Outputs(nn.Module):
    def __init__(self):
        super(Outputs, self).__init__()
        self.generator = GeneratorResnet()
        self.discriminator = Discriminator()
        self.discriminator_b = DiscriminatorB()
        self.content_encoder = ContentEncoder()
        self.segmentor = Segmentor()
        self.spf_cls = BuildSpfCls()

    def forward(self, inputs):
        images_a = inputs['images_a']
        images_b = inputs['images_b']

        fake_images_b = self.generator(images_a)
        dis_real_b = self.discriminator_b(images_b)
        dis_fake_b = self.discriminator_b(fake_images_b)

        inv_a, spf_a, logist_inv_a, logist_spf_a, inv_a_aux, spf_a_aux, logist_inv_a_aux, logist_spf_a_aux, Attn_a, Attn_a_aux = self.content_encoder(fake_images_b)
        inv_b, spf_b, logist_inv_b, logist_spf_b, inv_b_aux, spf_b_aux, logist_inv_b_aux, logist_spf_b_aux, Attn_b, Attn_b_aux = self.content_encoder(images_b)

        pred_real_a = self.segmentor(inv_a)
        pred_real_b = self.segmentor(inv_b)

        pred_real_a_aux = self.segmentor(inv_a_aux)
        pred_real_b_aux = self.segmentor(inv_b_aux)

        dis_a = torch.mul(nn.Softmax(dim=1)(pred_real_a), Attn_a)
        dis_b = torch.mul(nn.Softmax(dim=1)(pred_real_b), Attn_b)
        dis_pred_real_a = self.discriminator(dis_a)
        dis_pred_real_b = self.discriminator(dis_b)

        dis_a_aux = torch.mul(nn.Softmax(dim=1)(pred_real_a_aux), Attn_a_aux)
        dis_b_aux = torch.mul(nn.Softmax(dim=1)(pred_real_b_aux), Attn_b_aux)

        dis_pred_real_a_aux = self.discriminator(dis_a_aux)
        dis_pred_real_b_aux = self.discriminator(dis_b_aux)

        cls_spf_a = self.spf_cls(spf_a)
        cls_spf_b = self.spf_cls(spf_b)

        return {
            'spf_a': spf_a,
            'logist_spf_a': logist_spf_a,
            'spf_b': spf_b,
            'logist_spf_b': logist_spf_b,
            'inv_a': inv_a,
            'logist_inv_a': logist_inv_a,
            'inv_b': inv_b,
            'logist_inv_b': logist_inv_b,
            'pred_real_a': pred_real_a,
            'pred_real_b': pred_real_b,
            'dis_pred_real_a': dis_pred_real_a,
            'dis_pred_real_b': dis_pred_real_b,

            'spf_a_aux': spf_a_aux,
            'logist_spf_a_aux': logist_spf_a_aux,
            'spf_b_aux': spf_b_aux,
            'logist_spf_b_aux': logist_spf_b_aux,
            'inv_a_aux': inv_a_aux,
            'logist_inv_a_aux': logist_inv_a_aux,
            'inv_b_aux': inv_b_aux,
            'logist_inv_b_aux': logist_inv_b_aux,
            'pred_real_a_aux': pred_real_a_aux,
            'pred_real_b_aux': pred_real_b_aux,
            'dis_pred_real_a_aux': dis_pred_real_a_aux,
            'dis_pred_real_b_aux': dis_pred_real_b_aux,

            'fake_images_b': fake_images_b,
            'dis_real_b': dis_real_b,
            'dis_fake_b': dis_fake_b,

            'cls_spf_a': cls_spf_a,
            'cls_spf_b': cls_spf_b,
        }